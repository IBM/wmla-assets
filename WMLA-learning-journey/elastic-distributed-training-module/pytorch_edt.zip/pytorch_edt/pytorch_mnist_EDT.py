#!/usr/bin/env python3
# coding: utf-8

# # PyTorch transfer learning tutorial 

# Taken from this tutorial: https://pytorch.org/tutorials/beginner/transfer_learning_tutorial.html

from __future__ import print_function, division

import torch
import torch.nn as nn
import torch.optim as optim
from torch.optim import lr_scheduler
import numpy as np
import torchvision
from torchvision import datasets, models, transforms
import matplotlib.pyplot as plt
import time
import os
import copy

# EDT changes - additional libraries

import argparse
import sys
from os import environ
import json
import torch.nn.functional as F

# EDT changes - setting up enviroment variables. Note the additional helper scripts required 
# for EDT: edtcallback.py, emetrics.py and elog.py. These need to sit in the same directory
# as this code. Sample versions can be downloaded from http://ibm.biz/WMLA-samples.

path=os.path.join(os.getenv("FABRIC_HOME"), "libs", "fabric.zip")
print(path)
sys.path.insert(0,path)
from fabric_model import FabricModel
from edtcallback import EDTLoggerCallback

#dataDir = environ.get("DATA_DIR")
dataDir = '/gpfs/software/wmla-p10a117/wmla_sigs/notebooks/b0p036-spark231/b0p036-spark231/3b22bc91-2201-491a-9d46-bfda28f79197/Jupyter-5-4-0-23/config/hymenoptera_data'
if dataDir is not None:
    print("dataDir is: %s"%dataDir)
else:
    print("Warning: not found DATA_DIR from os env!")

model_path = os.environ["RESULT_DIR"]+"/model/saved_model"
tb_directory = os.environ["LOG_DIR"]+"/tb"
print ("model_path: %s" %model_path)
print ("tb_directory: %s" %tb_directory)

# Data augmentation and normalization for training
# Just normalization for validation

# EDT changes - replace the data loading functions with ones that return a tuple containing
# two items of type torch.utils.data.Dataset

def getDatasets():
    data_transforms = {
        'train': transforms.Compose([
            transforms.RandomResizedCrop(224),
            transforms.RandomHorizontalFlip(),
            transforms.ToTensor(),
            transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
        ]),
        'val': transforms.Compose([
            transforms.Resize(256),
            transforms.CenterCrop(224),
            transforms.ToTensor(),
            transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
        ]),
    }
    
    return (datasets.ImageFolder(os.path.join(dataDir, 'train'), data_transforms['train']),
            datasets.ImageFolder(os.path.join(dataDir, 'val'), data_transforms['val']))

# EDT changes - commenting out original dataset loaders and model training function 

# data_dir = '/home/username/hymenoptera_data'
# image_datasets = {x: datasets.ImageFolder(os.path.join(data_dir, x),
#                                           data_transforms[x])
#                   for x in ['train', 'val']}
# dataloaders = {x: torch.utils.data.DataLoader(image_datasets[x], batch_size=4,
#                                              shuffle=True, num_workers=4)
#               for x in ['train', 'val']}
# dataset_sizes = {x: len(image_datasets[x]) for x in ['train', 'val']}
# class_names = image_datasets['train'].classes

# device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")


# def train_model(model, criterion, optimizer, scheduler, num_epochs=25):
#     since = time.time()

#     best_model_wts = copy.deepcopy(model.state_dict())
#     best_acc = 0.0

#     for epoch in range(num_epochs):
#         print('Epoch {}/{}'.format(epoch, num_epochs - 1))
#         print('-' * 10)

#         # Each epoch has a training and validation phase
#         for phase in ['train', 'val']:
#             if phase == 'train':
#                 model.train()  # Set model to training mode
#             else:
#                 model.eval()   # Set model to evaluate mode

#             running_loss = 0.0
#             running_corrects = 0

#             # Iterate over data.
#             for inputs, labels in dataloaders[phase]:
#                 inputs = inputs.to(device)
#                 labels = labels.to(device)

#                 # zero the parameter gradients
#                 optimizer.zero_grad()

#                 # forward
#                 # track history if only in train
#                 with torch.set_grad_enabled(phase == 'train'):
#                     outputs = model(inputs)
#                     _, preds = torch.max(outputs, 1)
#                     loss = criterion(outputs, labels)

#                     # backward + optimize only if in training phase
#                     if phase == 'train':
#                         loss.backward()
#                         optimizer.step()

#                 # statistics
#                 running_loss += loss.item() * inputs.size(0)
#                 running_corrects += torch.sum(preds == labels.data)
#             if phase == 'train':
#                 scheduler.step()

#             epoch_loss = running_loss / dataset_sizes[phase]
#             epoch_acc = running_corrects.double() / dataset_sizes[phase]

#             print('{} Loss: {:.4f} Acc: {:.4f}'.format(
#                 phase, epoch_loss, epoch_acc))

#             # deep copy the model
#             if phase == 'val' and epoch_acc > best_acc:
#                 best_acc = epoch_acc
#                 best_model_wts = copy.deepcopy(model.state_dict())

#         print()

#     time_elapsed = time.time() - since
#     print('Training complete in {:.0f}m {:.0f}s'.format(
#         time_elapsed // 60, time_elapsed % 60))
#     print('Best val Acc: {:4f}'.format(best_acc))

#     # load best model weights
#     model.load_state_dict(best_model_wts)
#     return model

# EDT changes - define main function and parse parameters for training

def main():
    
    parser = argparse.ArgumentParser(description='PyTorch MNIST Example')
    parser.add_argument('--batchsize', type=int, default=64, metavar='N',
                        help='input batch size for training (default: 64)')
    parser.add_argument('--numWorker', type=int, default=100, metavar='N',
                        help='maxWorker')
    parser.add_argument('--epochs', type=int, default=5, metavar='N',
                        help='input epochs for training (default: 64)')

    args, unknow = parser.parse_known_args()
 
    print('args: ', args)
    print('numWorker args:', args.numWorker) 
    print('batch_size args:', args.batchsize)
    print('epochs args:', args.epochs)

# model_ft = models.resnet18(pretrained=True)
# num_ftrs = model_ft.fc.in_features
# # Here the size of each output sample is set to 2.
# # Alternatively, it can be generalized to nn.Linear(num_ftrs, len(class_names)).
# model_ft.fc = nn.Linear(num_ftrs, 2)

# model_ft = model_ft.to(device)

# criterion = nn.CrossEntropyLoss()

# # Observe that all parameters are being optimized
# optimizer_ft = optim.SGD(model_ft.parameters(), lr=0.001, momentum=0.9)

# # Decay LR by a factor of 0.1 every 7 epochs
# exp_lr_scheduler = lr_scheduler.StepLR(optimizer_ft, step_size=7, gamma=0.1)


# model_ft = train_model(model_ft, criterion, optimizer_ft, exp_lr_scheduler,
#                        num_epochs=25)

    model_conv = torchvision.models.resnet18(pretrained=True)
    for param in model_conv.parameters():
        param.requires_grad = False

# Parameters of newly constructed modules have requires_grad=True by default
    num_ftrs = model_conv.fc.in_features
    model_conv.fc = nn.Linear(num_ftrs, 2)

# model_conv = model_conv.to(device)

    criterion = nn.CrossEntropyLoss()

# Observe that only parameters of final layer are being optimized as
# opposed to before.
    optimizer_conv = optim.SGD(model_conv.fc.parameters(), lr=0.001, momentum=0.9)

# Decay LR by a factor of 0.1 every 7 epochs
    exp_lr_scheduler = lr_scheduler.StepLR(optimizer_conv, step_size=7, gamma=0.1)

# EDT changes - Replace the training and testing loops with EDT equivalents

# model_conv = train_model(model_conv, criterion, optimizer_conv,
#                          exp_lr_scheduler, num_epochs=25)

    edt_m = FabricModel(model_conv, getDatasets, F.nll_loss, optimizer_conv, driver_logger=EDTLoggerCallback())
    edt_m.train(args.epochs, args.batchsize, args.numWorker,checkpoint_freq=5)

if __name__ == '__main__':
    print('sys.argv: ', sys.argv)
    main()
