from __future__ import print_function
import argparse
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import torchvision
from torchvision import datasets, transforms
from torch.optim import lr_scheduler
from pathlib import Path

import sys
import os
from os import environ
import json

currentDir = os.getenv('KERNEL_NOTEBOOK_DATA_DIR')
if currentDir is not None:
    print ("currentDir: " + currentDir)
else:
    print ("currentDir none")


#  Importing libraries and setting up enviroment variables 
path=os.path.join(os.getenv("FABRIC_HOME"), "libs", "fabric.zip")
print(path)
sys.path.insert(0,path)
from fabric_model import FabricModel
from edtcallback import EDTLoggerCallback

workingDir = os.getcwd()
print ("workingDir is: " + workingDir) 

# dataDir = environ.get("DATA_DIR")
os.chdir("..")
os.chdir("..")
os.chdir("..")

#dataDir = '/gpfs/software/wmla-p10a117/wmla_sigs/notebooks/b0p036-spark231/b0p036-spark231/3b22bc91-2201-491a-9d46-bfda28f79197/Jupyter-5-4-0-23/config/hymenoptera_data/'

dataDir = currentDir + '/config/hymenoptera_data/'

if dataDir is not None:
    print("dataDir is: %s"%dataDir)
else:
    print("Warning: not found DATA_DIR from os env!")



model_path = os.environ["RESULT_DIR"]+"/model/saved_model"
tb_directory = os.environ["LOG_DIR"]+"/tb"
print ("model_path: %s" %model_path)
print ("tb_directory: %s" %tb_directory)

# Data Loading function for EDT


def getDatasets():
    return (datasets.MNIST(dataDir, train=True, download=True, 
                       transform=transforms.Compose([
                           transforms.ToTensor(),
                           transforms.Normalize((0.1307,), (0.3081,))
                       ])),
            datasets.MNIST(dataDir, train=False, transform=transforms.Compose([
                           transforms.ToTensor(),
                           transforms.Normalize((0.1307,), (0.3081,))
                       ]))
            )

"""
def getDatasets():
    data_transforms = {
    'train': transforms.Compose([
        transforms.RandomResizedCrop(224),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
    ]),
    'val': transforms.Compose([
        transforms.Resize(256),
        transforms.CenterCrop(224),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
    ]),
    }

    return (datasets.ImageFolder(os.path.join(dataDir, 'train'), data_transforms['train']),
            datasets.ImageFolder(os.path.join(dataDir, 'val'), data_transforms['val']))
"""

def main():

  
    # Extract parameters for training
    parser = argparse.ArgumentParser(description='PyTorch MNIST Example')
    parser.add_argument('--batchsize', type=int, default=64, metavar='N',
                        help='input batch size for training (default: 64)')
    parser.add_argument('--numWorker', type=int, default=100, metavar='N',
                        help='maxWorker')

    parser.add_argument('--epochs', type=int, default=5, metavar='N',
                        help='input epochs for training (default: 64)')

    args, unknow = parser.parse_known_args()
 
    print('args: ', args)
    print('numWorker args:', args.numWorker) 
    print('batch_size args:', args.batchsize)
    print('epochs args:', args.epochs)
    
    #Define Model
    model_conv = torchvision.models.resnet18(pretrained=True)
    for param in model_conv.parameters():
        param.requires_grad = False

    num_ftrs = model_conv.fc.in_features
    model_conv.fc = nn.Linear(num_ftrs, 2)
    criterion = nn.CrossEntropyLoss()
    
    optimizer_conv = optim.SGD(model_conv.fc.parameters(), lr=0.1, momentum=0.9)
    exp_lr_scheduler = lr_scheduler.StepLR(optimizer_conv, step_size=7, gamma=0.1)

  
    # Replace the training and testing loops with EDT equivalents
    edt_m = FabricModel(model_conv, getDatasets, F.nll_loss, optimizer_conv, driver_logger=EDTLoggerCallback())
    edt_m.train(args.epochs, args.batchsize, args.numWorker)
if __name__ == '__main__':
    print('sys.argv: ', sys.argv)
    main()

