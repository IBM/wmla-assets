#!/bin/sh
which conda
conda env list
source activate dli-xgboost
python $@

