#!/usr/bin/env python2
import os.path, sys
from os import environ

"""
"""

def main():

   cmd = ""

   if "DLI_SHARED_FS" in os.environ:
      print (environ.get('DLI_SHARED_FS'))
      cmd = environ.get('DLI_SHARED_FS') + "/tools/spark_tf_launcher/launcher.py"
   else:
      print("Error: environment variable DLI_SHARED_FS must be defined")
      sys.exit()

   if "APP_NAME" in os.environ:
      cmd = cmd + " --sparkAppName=" + environ.get('APP_NAME')
   else:
      print("Error: environment variable APP_NAME must be defined")
      sys.exit()

   if "MODEL" in os.environ:
      cmd = cmd + " --model=" + environ.get('MODEL')
   else:
      print("Error: environment variable MODEL must be defined")
      sys.exit()

   if "REDIS_HOST" in os.environ:
      cmd = cmd + " --redis_host=" + environ.get('REDIS_HOST')
   else:
      print("Error: environment variable REDIS_HOST must be defined")
      sys.exit()

   if "REDIS_PORT" in os.environ:
      cmd = cmd + " --redis_port=" + environ.get('REDIS_PORT')
   else:
      print("Error: environment variable REDIS_PORT must be defined")
      sys.exit()

   if "GPU_PER_WORKER" in os.environ:
      cmd = cmd + " --devices=" + environ.get('GPU_PER_WORKER')
   else:
      print("Error: environment variable GPU_PER_WORKER must be defined")
      sys.exit()

   cmd = cmd + " --work_dir=" + os.path.dirname(environ.get('MODEL'))
   cmd = cmd + " --app_type=executable"
   
   cmd = cmd + " --model=" + environ.get('DLI_SHARED_FS') + "/tools/dl_plugins/XGboost_wrapper.sh --"
   cmd = cmd + " " + environ.get('MODEL')

   # adding user args
   for i in range(1, len(sys.argv)):
      cmd += " " + sys.argv[i]

   # Expected result in json
   print('{"CMD" : "%s"}' % cmd)

if __name__ == "__main__":
   sys.exit(main())

