#!/bin/bash

source ./scripts/common.inc
source ./scripts/jupyter.inc

: '
    Error Codes:
        1 - Error when creating directory
        2 - Failed to create directory
        3 - The deploy directory already exists
        4 - Failed to copy files
        5 - Failed to run anaconda
        6 - Unimplemented - Modify notebook
        7 - NOTEBOOK_DEPLOY_DIR is not defined
        8 - Failed to touch file
        9 - Directory is not defined
        10 - Directory already exists
        11 - Failed to setfacl
        12 - Failed to extract static Jupyter package
        13 - Failed to install Jupyter package
        14 - Failed to update the deployment timestamp
'

declare -r INSTALLDIR="$NOTEBOOK_DEPLOY_DIR/install"
declare -r NOTEBOOK_SERVICELOGS_DIR="$NOTEBOOK_DEPLOY_DIR/service_logs"
declare -r JUPYTER_DATA_DIR="${NOTEBOOK_DATA_BASE_DIR}/${APP_NAME}/${APP_UUID}"
#######################
### Utility Methods ###
#######################

make_directory() {
    # $1 Directory path
    # $2 Optional permissions

    local path="$1"
    local perm="$2"

    if [ -n "$perm" ]; then
        mkdir -p -m $perm $path
    else
        mkdir -p $path
    fi

    local rc="$?"
    if [ "$rc" -ne 0 ]; then
        echo "Error when trying to create directory $path. Exit code: $rc"
        exit 1
    fi

    if [ ! -d "$path" ]; then
        echo "Failed to create directory $path."
        exit 2
    fi
}

make_directory_with_multilevel_permission() {
    # $1 Directory path
    # $2 Optional destination directory permissions
    # $3 Optional intermediate directory permissions (multilevel directory)
    local path="$1"
    local destperm="$2"
    local interperm="$3"

    if [ -z "$path" ]; then
        echo "Directory is not defined"
        exit 9
    fi

    if [ -d "$path" ]; then
        echo "$path already exists"
        exit 10
    fi
    
    #remove extra slashes in the path
    path=$(sed 's/\/\+/\//g'<<<"$path")
    
    IFS=/
    array=($path)
    unset IFS
    partialpath=""

    for dir in "${array[@]}"; do
        if [ -n "$dir" ]; then
            partialpath="${partialpath}/${dir}"
            if [ ! -d "$partialpath" ]; then
                mkdir "$partialpath"
                local rc="$?"
                if [ "$rc" -ne 0 ]; then
                    echo "Error when trying to create directory $path. Exit code: $rc"
                    exit 1
                fi
                if [ "${partialpath%/}" == "${path%/}" ]; then
                    :
                else
                    chmod $interperm "$partialpath"
                fi
            fi
        fi
    done
}

copy_files() {
    # $1 Source path
    # $2 Dest path
    # $3 Optional flags

    local source_path="$1"
    local dest_path="$2"
    local flags="$3"

    if [ -n "$flags" ]; then
        cp $flags $source_path $dest_path
    else
        cp $source_path $dest_path
    fi

    local rc="$?"
    if [ "$rc" -ne 0 ]; then
        echo "Failed to copy $source_path to $dest_path. Exit code: $rc"
        exit 4
    fi
}

touch_file() {
    # $1 Filepath

    local filepath="$1"

    touch $filepath

    local rc="$?"
    if [ "$rc" -ne 0 ]; then
        if [ -z "$OLD_NOTEBOOK_EXEC_USER" ]; then
            echo "Failed to touch file $filepath. Exit code: $rc"
            exit 8
        else
            echo "$IBM_PLATFORM_DEPLOY_HOOK_EXEC_USER is not the file owner of $(dirname $filepath)."\
            "Manually change $IBM_PLATFORM_DEPLOY_HOOK_EXEC_USER as the owner of $(dirname $filepath)"\
            "or specify a new Notebook base data directory and retry the deployment."
            exit 8
        fi
    fi
}

remove_files() {
	# $1 Path
	# $2 Optional flags

	local path="$1"
	local flags="$2"
	
	if [ -n "$flags" ]; then
		rm $flags $path
	else
		rm $path
	fi
	
	local rc="$?"
	if [ "$rc" -ne 0 ]; then
		echo "Failed to remove $path. Exit code: $rc"
		exit 7
	fi
}

setfacl_user_command() {
    # $1 Username
    # $2 Permission string (i.e. "rwx")
    # $3 Path
    # $4 Optional Flags

    local username="$1"
    local permission="$2"
    local path="$3"
    local flags="$4"

    setfacl $flags u:$username:$permission $path

    local rc="$?"
    if [ "$rc" -ne 0 ]; then
        #Don't fail outright, since we know setfacl does not work on NFS.
        #Check if the user exists
        if [ -z `id -u $username 2>/dev/null` ]; then
            echo "Failed to setfacl for $path. The user $username does not exist."
            exit 11
        fi
    fi
}

setfacl_mask_command() {
        # $1 Permission string (i.e. "rwx")
        # $2 Path
        # $3 Optional Flags

        local permission="$1"
        local path="$2"
        local flags="$3"

        setfacl $flags m:$permission $path

        local rc="$?"
        if [ "$rc" -ne 0 ]; then
        	echo "Failed to setfacl mask for $path."
        fi
}

is_ok_to_use_deploy_home() {
	
	if [ ! -e "$NOTEBOOK_DEPLOY_DIR" ]; then
		#Path does not exist, ok to use it
		echo 0
	else
		if [ ! -d "$NOTEBOOK_DEPLOY_DIR" ]; then
			#The path is a file, not a directory, we can't deploy to it
			echo 1
		else
			if [ -e "$NOTEBOOK_DEPLOY_DIR/$CREATED_BY_CONDUCTOR_FOR_SPARK_FILE" ]; then
				#The .uuid file exists, the directory belongs to this Spark instance group
				echo 0
			else
				#The directory exists, but the .uuid file does not exist
				if [ $(find "$NOTEBOOK_DEPLOY_DIR" -maxdepth 0 -type d -empty 2>/dev/null) ]; then
					#The directory is empty, it is OK to use it
					echo 0
				else
					#The directory is not empty, check what it contains
					if [ -d "$NOTEBOOK_SERVICELOGS_DIR" ]; then
						#The service_logs directory exists, check if there is anything else
						if [ $(find "$NOTEBOOK_DEPLOY_DIR" -maxdepth 1 ! -name service_logs | wc -l) -eq 1 ]; then
							#The service_logs directory is the only thing in the dir, it is OK to use it
							echo 0
						else
							#There are other files in the directory aside from the service_logs directory
							#We can't deploy to it
							echo 1
						fi
					else
						#The service_logs directory does not exist, so the directory must have other contents
						#We can't deploy to it
						echo 1
					fi
				fi
			fi 
		fi
	fi
	
}

##########################
### Functional Methods ###
##########################

verify_notebook_deploy_dir_defined() {
    if [ -z "$NOTEBOOK_DEPLOY_DIR" ]; then
        echo "NOTEBOOK_DEPLOY_DIR is not defined."
        exit 7
    fi
}

clean_up_logs() {
    # Back up the service log files if the execution user for the service has changed
    # $1 file path
    # $2 file pattern
    # $3 new username

    local file_path="$1"
    local file_pattern="$2"
    local new_username="$3"

    if [ -n "$new_username" ]; then
        local files_matching_pattern=$(ls -ld ${file_path}/* | grep ${file_pattern} | grep -v ".old-" | awk '{print $9}')
        if [ ${#files_matching_pattern[@]} -ne 0 ]; then
            for f in ${files_matching_pattern[@]}
            do
                local old_username=$(ls -ld $f | awk '{print $3}')
                if [ "$old_username" != "$new_username" ]; then
                CONSUMER_USER_CHANGED=true
                mv $f $f.old-$old_username
                fi
            done
        fi
    fi
}

clean_up_all_service_logs() {
    if [ -n "$NOTEBOOK_CONSUMER_EXEC_USER" ]; then
        clean_up_logs $NOTEBOOK_SERVICELOGS_DIR "$APP_NAME-.*.log" $NOTEBOOK_CONSUMER_EXEC_USER
    fi
}

create_notebook_deploy_dir() {
    if [ ! -d "$NOTEBOOK_DEPLOY_DIR" ]; then
        make_directory_with_multilevel_permission $NOTEBOOK_DEPLOY_DIR 755 775
        touch_file $NOTEBOOK_DEPLOY_DIR/$CREATED_BY_CONDUCTOR_FOR_SPARK_FILE
        if [ -n "$NOTEBOOK_CONSUMER_EXEC_USER" ]; then
            setfacl_user_command $NOTEBOOK_CONSUMER_EXEC_USER "rwx" $NOTEBOOK_DEPLOY_DIR "-m"
        fi
    elif [ $(is_ok_to_use_deploy_home) -eq 0 ]; then
    	if [ -e "$NOTEBOOK_DEPLOY_DIR/$CREATED_BY_CONDUCTOR_FOR_SPARK_FILE" ]; then
    		remove_files $NOTEBOOK_DEPLOY_DIR/$CREATED_BY_CONDUCTOR_FOR_SPARK_FILE
    	fi
    	touch_file $NOTEBOOK_DEPLOY_DIR/$CREATED_BY_CONDUCTOR_FOR_SPARK_FILE
		if [ -n "$NOTEBOOK_CONSUMER_EXEC_USER" ]; then
			setfacl_user_command $NOTEBOOK_CONSUMER_EXEC_USER "rwx" $NOTEBOOK_DEPLOY_DIR "-m"
		fi
    else
    	echo "The notebook deployment directory ${NOTEBOOK_DEPLOY_DIR} already exists and does not belong to the Spark instance group with the ID $APP_UUID."
    	exit 3
    fi
}

create_notebook_base_dir() {
    # check whether current user has enough write and read permission to NOTEBOOK_DATA_BASE_DIR
    if [ -d "$NOTEBOOK_DATA_BASE_DIR" ]; then
        # check write permission
        touch_file ${NOTEBOOK_DATA_BASE_DIR}/temp.txt
        rm -f ${NOTEBOOK_DATA_BASE_DIR}/temp.txt
    else
        make_directory_with_multilevel_permission $NOTEBOOK_DATA_BASE_DIR 755 775
    fi

    setfacl_user_command $IBM_PLATFORM_DEPLOY_HOOK_EXEC_USER "rwx" $NOTEBOOK_DATA_BASE_DIR "-d -m"

    if [ -n "$NOTEBOOK_CONSUMER_EXEC_USER" ]; then
        setfacl_user_command $NOTEBOOK_CONSUMER_EXEC_USER "rwx" $NOTEBOOK_DATA_BASE_DIR "-m"
    else
        setfacl_user_command $IBM_PLATFORM_DEPLOY_HOOK_EXEC_USER "rwx" $NOTEBOOK_DATA_BASE_DIR "-m"
    fi

    if [ ! -d "$JUPYTER_DATA_DIR" ]; then
        make_directory_with_multilevel_permission $JUPYTER_DATA_DIR 775 755
        chmod 775 $JUPYTER_DATA_DIR
    else
        # check write permission
        touch_file ${JUPYTER_DATA_DIR}/temp.txt
        rm -f ${JUPYTER_DATA_DIR}/temp.txt
    fi

    setfacl_user_command $IBM_PLATFORM_DEPLOY_HOOK_EXEC_USER "rwx" $JUPYTER_DATA_DIR "-d -m"

    if [ -n "$NOTEBOOK_CONSUMER_EXEC_USER" ]; then
        setfacl_user_command $NOTEBOOK_CONSUMER_EXEC_USER "rwx" $JUPYTER_DATA_DIR "-m"
    else
        setfacl_user_command $IBM_PLATFORM_DEPLOY_HOOK_EXEC_USER "rwx" $JUPYTER_DATA_DIR "-m"
    fi
}

copy_scripts_dir () {
    copy_files ./scripts $NOTEBOOK_DEPLOY_DIR/ "-r"
    find ./scripts/* ! -name deploy.sh ! -name undeploy.sh ! -name *.inc -exec rm -f {} \;
}

install_jupyter_using_anaconda() {
    copy_files ./package/$ANACONDA_SCRIPT_NAME $NOTEBOOK_DEPLOY_DIR/
    cd $NOTEBOOK_DEPLOY_DIR

    bash $ANACONDA_SCRIPT_NAME -b -p $INSTALLDIR
    if [ "$?" -ne 0 ]; then
        echo "Failed to run anaconda setup."
        exit 5
    fi
    #rm -rf $ANACONDA_SCRIPT_NAME
}

pin_package_versions() {

    PINNED_PACKS=$NOTEBOOK_DEPLOY_DIR/scripts/pinned_packs

    echo "Pinning conda package versions..."
   
    echo "anaconda dir = $NOTEBOOK_DEPLOY_DIR/"
 
    echo "pinned conda packages:"
    cat $PINNED_PACKS

    cp $PINNED_PACKS $NOTEBOOK_DEPLOY_DIR/install/conda-meta/pinned

}


install_powerai_deps() {

    ## workaround for customer's proxy
    [ -e /etc/profile.d/proxy.sh ] && source /etc/profile.d/proxy.sh
    

    PAI_DIR=/opt/DL
    LOG=/tmp/PAI_notebook_pre.log

    OLDPATH=`echo $PATH`
    OLDHOME=`echo $HOME` 
 
    echo "old path: $OLDPATH"
    echo "old home: $OLDHOME"

    USER=`whoami`
    echo "user: $USER"
    export HOME=/home/$USER
    echo "home: $HOME"

    echo "PAI_DIR = $PAI_DIR"
    PATH=`echo $PATH`

    echo "anaconda dir = $NOTEBOOK_DEPLOY_DIR/install/bin"

    #put anaconda in the PATH
    export PATH=$NOTEBOOK_DEPLOY_DIR/install/bin:$PATH
    echo "PATH=$PATH"

    echo "calling: $PAI_DIR/tensorboard/bin/install_dependencies -y -q"
    $PAI_DIR/tensorboard/bin/install_dependencies -y

    echo "calling: $PAI_DIR/tensorflow/bin/install_dependencies -y -q"
    $PAI_DIR/tensorflow/bin/install_dependencies -y

    echo "calling $PAI_DIR/pytorch/bin/install_dependencies -y -q"
    $PAI_DIR/pytorch/bin/install_dependencies -y -q

    echo "calling $PAI_DIR/snap-ml-mpi/bin/install_dependencies"
    /opt/DL/snap-ml-mpi/bin/install_dependencies -y -q

    echo "calling $PAI_DIR/snap-ml-local/bin/install_dependencies"
    /opt/DL/snap-ml-local/bin/install_dependencies -y -q

    echo "calling $PAI_DIR/snap-ml-mpi/bin/install_dependencies"
    /opt/DL/snap-ml-mpi/bin/install_dependencies -y -q

    echo "calling $PAI_DIR/caffe/bin/install_dependencies"
    /opt/DL/caffe/bin/install_dependencies  -y -q


    export PATH=$OLDPATH
    export HOME=$OLDHOME

    echo "powerAI dependencies installed"
}

install_custom_packages() {
    PACKS=`cat $NOTEBOOK_DEPLOY_DIR/scripts/added_packs`
    echo "PACKS: $PACKS"

    ## workaround for customer's proxy
    [ -e /etc/profile.d/proxy.sh ] && source /etc/profile.d/proxy.sh

    OLDPATH=`echo $PATH`
    OLDHOME=`echo $HOME` 
 
    echo "old path: $OLDPATH"
    echo "old home: $OLDHOME"

    USER=`whoami`
    echo "user: $USER"
    export HOME=/home/$USER
    echo "home: $HOME"

    echo "anaconda dir = $NOTEBOOK_DEPLOY_DIR/install/bin"

    #put anaconda in the PATH
    export PATH=$NOTEBOOK_DEPLOY_DIR/install/bin:$PATH
    echo "PATH=$PATH"

    echo "workaround for matplotlib bug, December 2018"
    conda update matplotlib -y
    echo "matplotlib workaround complete"

    echo "calling: pip install $PACKS"
    pip install $PACKS

    echo "Make sure that ipywidgets is properly installed by running for sparkmagic"
    jupyter nbextension enable --py --sys-prefix widgetsnbextension

    export PATH=$OLDPATH
    export HOME=$OLDHOME

    echo "additional pip packages installed"

}

copy_loginegoauth() {
    SITE_PACKAGE_PATH=`find $NOTEBOOK_DEPLOY_DIR/install/lib -name "*site-package*"`
    copy_files ./scripts/loginegoauth.py $SITE_PACKAGE_PATH/notebook/auth/
    copy_files ./scripts/loginegoauth.html $SITE_PACKAGE_PATH/notebook/templates/
}

create_service_logs_dir() {
    #Make service_logs dir
    if [ ! -d "$NOTEBOOK_SERVICELOGS_DIR" ]; then
        make_directory_with_multilevel_permission $NOTEBOOK_SERVICELOGS_DIR 755 775
    fi
    setfacl_user_command $IBM_PLATFORM_DEPLOY_HOOK_EXEC_USER "rwx" $NOTEBOOK_SERVICELOGS_DIR "-d -m"
    if [ -n "$NOTEBOOK_CONSUMER_EXEC_USER" ]; then
        setfacl_user_command $NOTEBOOK_CONSUMER_EXEC_USER "rwx" $NOTEBOOK_SERVICELOGS_DIR "-m"
    else
        setfacl_user_command $IBM_PLATFORM_DEPLOY_HOOK_EXEC_USER "rwx" $NOTEBOOK_SERVICELOGS_DIR "-m"
    fi
}

deploy_new_jupyter_notebook() {
    echo "Deploy Jupyter notebook to $NOTEBOOK_DEPLOY_DIR"
    create_notebook_deploy_dir
    create_notebook_base_dir
    create_service_logs_dir
    copy_scripts_dir
    install_jupyter_using_anaconda
    pin_package_versions
    install_custom_packages
    install_powerai_deps
    copy_loginegoauth
}

deploy_updated_jupyter_notebook() {
    echo "NOTEBOOK_UPDATE_PACKAGE=true. Updating Jupyter notebook."   
    create_notebook_deploy_dir
    create_notebook_base_dir
    create_service_logs_dir
    copy_scripts_dir
    install_jupyter_using_anaconda
    pin_package_versions
    install_custom_packages
    install_powerai_deps
    copy_loginegoauth
}

redeploy_jupyter_notebook_for_major_config_change() {
    deploy_new_jupyter_notebook
}

redeploy_jupyter_notebook_for_minor_config_change() {
	if [ $(is_ok_to_use_deploy_home) -ne 0 ]; then
		echo "The notebook deployment directory $NOTEBOOK_DEPLOY_DIR exists and does not belong to the Spark instance group with ID $APP_UUID."
		exit 3
	fi
    clean_up_all_service_logs
    create_notebook_base_dir
    create_service_logs_dir
}

deploy_jupyter_if_available() {
	if [ -e "./package/$ANACONDA_SCRIPT_NAME" ]; then
		if [ -z "$OLD_NOTEBOOK_DEPLOY_DIR" ] && [ -z "$OLD_NOTEBOOK_EXEC_USER" ]; then
            if [ ! -f "${NOTEBOOK_DEPLOY_DIR}/scripts/common.inc" ]; then
                echo "Notebook deployment directory not found. Deploy new notebook."
                deploy_new_jupyter_notebook
            else
            	echo "Notebook deployment directory exists. Update notebook."
				NOTEBOOK_UPDATE_PACKAGE=true
				cleanup_notebook_deployment
                deploy_updated_jupyter_notebook
            fi
        else
            echo "Redeploy notebook to new deploy directory."
            if [ -f "${NOTEBOOK_DEPLOY_DIR}/scripts/common.inc" ]; then
            	cleanup_notebook_deployment
            fi
            redeploy_jupyter_notebook_for_major_config_change
        fi
	else
		echo "Anaconda script does not exist. Update notebook configuration."
		redeploy_jupyter_notebook_for_minor_config_change
	fi  

}

update_timestamp_file() {

	if [ -n "$LAST_UPDATED_TIMESTAMP" ]; then
		if [ -e "$LAST_UPDATE_TIMESTAMP_FILE" ]; then
			local current_timestamp=`head -n 1 $LAST_UPDATE_TIMESTAMP_FILE`
			if [ "$LAST_UPDATED_TIMESTAMP" -ne "$current_timestamp" ]; then
				echo "$LAST_UPDATED_TIMESTAMP" > $LAST_UPDATE_TIMESTAMP_FILE
				if [ "$?" -ne 0 ]; then
					echo "Failed to update the timestamp in $LAST_UPDATE_TIMESTAMP_FILE."
					exit 14
				fi
			fi
		else
			echo "$LAST_UPDATED_TIMESTAMP" > $LAST_UPDATE_TIMESTAMP_FILE
			if [ "$?" -ne 0 ]; then
				echo "Failed to update the timestamp in $LAST_UPDATE_TIMESTAMP_FILE."
				exit 14
			fi
		fi
	fi	
}

main() {
    verify_notebook_deploy_dir_defined
    if [ -z "$NOTEBOOK_UPDATE_PARAMETER" ] && [ -z "$NOTEBOOK_UPDATE_PACKAGE" ] && [ -z "$ASCD_DEPLOY_SINGLE_HOST" ]; then
        deploy_new_jupyter_notebook
    elif [ -n "$ASCD_DEPLOY_SINGLE_HOST" ]; then
    	deploy_jupyter_if_available
    elif [ -n "$NOTEBOOK_UPDATE_PACKAGE" ]; then
        deploy_updated_jupyter_notebook
    elif [ -n "$NOTEBOOK_UPDATE_PARAMETER" ]; then
        if [ -z "$OLD_NOTEBOOK_DEPLOY_DIR" ] && [ -z "$OLD_NOTEBOOK_EXEC_USER" ]; then
            if [ ! -f "${NOTEBOOK_DEPLOY_DIR}/scripts/common.inc" ]; then
                echo "Notebook deployment directory not found. Redeploying Notebook."
                deploy_new_jupyter_notebook
            else
                redeploy_jupyter_notebook_for_minor_config_change
            fi
        else
            echo "Redeploy to new deploy directory."
            redeploy_jupyter_notebook_for_major_config_change
        fi  
    fi
    
    #Always check if timestamp should be updated as last step in the deployment
	update_timestamp_file
}

main "$@"
