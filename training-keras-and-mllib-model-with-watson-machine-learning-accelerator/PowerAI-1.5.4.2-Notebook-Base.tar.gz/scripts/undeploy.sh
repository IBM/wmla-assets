#!/bin/bash

source ./scripts/common.inc
source ./scripts/jupyter.inc

function main() {
	if [ -n "$NOTEBOOK_UPDATE_PARAMETER" ]; then
		if [[ -n "$OLD_NOTEBOOK_DEPLOY_DIR" && "$OLD_NOTEBOOK_DEPLOY_DIR" != "$NOTEBOOK_DEPLOY_DIR" ]]; then
			export NOTEBOOK_DEPLOY_DIR="$OLD_NOTEBOOK_DEPLOY_DIR"
			cleanup_notebook_deployment
		elif [ -n "$OLD_NOTEBOOK_EXEC_USER" ]; then
			cleanup_notebook_deployment
		elif [ -n "$NOTEBOOK_UPDATE_PACKAGE" ]; then
            cleanup_notebook_deployment
		else
			exit 0
		fi
	else
		cleanup_notebook_deployment
	fi
}

main "$@"