import os
import sys

spark_home = os.environ.get('SPARK_HOME', None)
if not spark_home:
      raise ValueError('SPARK_HOME environment variable is not set')
sys.path.insert(0, os.path.join(spark_home, 'python'))
tmpDir = os.path.join(spark_home,'python/lib/')
tmpStr = "py4j"
joinDir = tmpDir
for root, dirs, files in os.walk(tmpDir):
        for f in files:
                if tmpStr in f:
                        joinDir = os.path.join(tmpDir,f)
                        break
if joinDir == tmpDir:
        raise ValueError('py4j library is not set in spark_home dir')

sys.path.insert(0, joinDir)
exec(open(os.path.join(spark_home, 'python/pyspark/shell.py')).read())
