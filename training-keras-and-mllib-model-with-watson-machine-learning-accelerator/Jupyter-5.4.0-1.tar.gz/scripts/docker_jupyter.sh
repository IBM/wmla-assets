#!/bin/bash

source ${NOTEBOOK_DEPLOY_DIR}/scripts/common.inc
source ${NOTEBOOK_DEPLOY_DIR}/scripts/jupyter.inc

all_input=$@

trap 'cleanup; exit' SIGINT SIGQUIT SIGTERM

cleanup()
{
   cd ${NOTEBOOK_DEPLOY_DIR}
   bash ./scripts/stop_jupyter.sh
}

dockeripython() {
		local start_jupyter_script="start_jupyter.sh"
        
        cd ${NOTEBOOK_DEPLOY_DIR}
        
        #Check timestamp first to ensure notebook deployment is up to date
		validate_timestamp
        
        #Start the notebook
        bash ./scripts/$start_jupyter_script $all_input &

        retrialnum=0
        while [ $retrialnum -le 9 ]
        do
            sleep 10
            grepfile=`find $JUPYTER_DATA_DIR/runtime/ -name nbserver-*.json`
            if [ -f "$grepfile" ] ;then
                sleep 5
                port2tmp=`cat $grepfile |grep \"port\" |awk -F': ' '{print $2}'`
                port=${port2tmp%,*}
                if [ -n "$port" ] ;then
                   echo $port > $PORT_FILE
                else
                   cleanup
                   exit 1
                fi
            else
               	#Check if the start_jupyster.sh script is still running
	    		ps -ef | grep $start_jupyter_script | grep -v grep > /dev/null
	    		if [ $? -ne 0 ]; then
	    			echo_log "ERROR: The $start_jupyter_script script has exited."
	    			cleanup
	    			exit 3
	    		fi
                retrialnum=$(($retrialnum + 1))
            fi
        done
        if [ $retrialnum -le 10 ] ;then
             cleanup
             exit 2
        fi
}
exec > >(tee -a $DOCKER_SERVICE_LOGFILE) 2>&1
dockeripython
