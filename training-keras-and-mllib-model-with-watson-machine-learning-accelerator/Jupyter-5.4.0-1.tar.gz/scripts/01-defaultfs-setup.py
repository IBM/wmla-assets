import os

#This script will set the hadoop configuration for SparkContext if a data connector for fs.defaultFS is defined for the Spark instance group

core_site_xml_filename=os.environ.get('CORE_SITE_DEFAULTFS_XML_FILENAME')
if core_site_xml_filename != None:
    hadoopConf=sc._jsc.hadoopConfiguration()
    hadoopConf.addDefaultResource(core_site_xml_filename)
