#!/bin/bash

source ./scripts/common.inc
source ./scripts/jupyter.inc

: '
    Error Codes:
        1 - Error when creating directory
        2 - Failed to create directory
        3 - The deploy directory already exists
        4 - Failed to copy files
        5 - Failed to run anaconda
        6 - Unimplemented - Modify notebook
        7 - NOTEBOOK_DEPLOY_DIR is not defined
        8 - Failed to touch file
        9 - Directory is not defined
        10 - Directory already exists
        11 - Failed to setfacl
        12 - Failed to extract static Jupyter package
        13 - Failed to install Jupyter package
        14 - Failed to update the deployment timestamp
        15 - Failed to install JEG
        16 - Failed to install NB2KG
        17 - Failed to generate JEG config
        18 - Failed to enable NB2KG extension
        19 - Failed to run Jupyter command
'

declare -r INSTALLDIR="$NOTEBOOK_DEPLOY_DIR/install"
declare -r NOTEBOOK_SERVICELOGS_DIR="$NOTEBOOK_DEPLOY_DIR/service_logs"
declare -r JUPYTER_DATA_DIR="${NOTEBOOK_DATA_BASE_DIR}/${APP_NAME}/${APP_UUID}"
declare -r DISABLE_TERMINAL="${DISABLE_JUPYTER_TERMINAL}"
if [ "${JEG_ENABLED}" == "TRUE" ]; then
    declare -r JEG_PACKAGE_DIR="jupyter_enterprise_gateway-${JEG_VERSION}"
    declare -r JEG_PACKAGE="${JEG_PACKAGE_DIR}.tar.gz"
    declare -r JEG_INSTALL_PACKAGE_NAME="jupyter_enterprise_gateway"
    declare -r NB2KG_INSTALL_PACKAGE_NAME="nb2kg"
fi
#######################
### Utility Methods ###
#######################

make_directory() {
    # $1 Directory path
    # $2 Optional permissions

    local path="$1"
    local perm="$2"

    if [ -n "$perm" ]; then
        mkdir -p -m $perm $path
    else
        mkdir -p $path
    fi

    local rc="$?"
    if [ "$rc" -ne 0 ]; then
        echo "Error when trying to create directory $path. Exit code: $rc"
        exit 1
    fi

    if [ ! -d "$path" ]; then
        echo "Failed to create directory $path."
        exit 2
    fi
}

make_directory_with_multilevel_permission() {
    # $1 Directory path
    # $2 Optional destination directory permissions
    # $3 Optional intermediate directory permissions (multilevel directory)
    local path="$1"
    local destperm="$2"
    local interperm="$3"

    if [ -z "$path" ]; then
        echo "Directory is not defined"
        exit 9
    fi

    if [ -d "$path" ]; then
        echo "$path already exists"
        exit 10
    fi
    
    #remove extra slashes in the path
    path=$(sed 's/\/\+/\//g'<<<"$path")
    
    IFS=/
    array=($path)
    unset IFS
    partialpath=""

    for dir in "${array[@]}"; do
        if [ -n "$dir" ]; then
            partialpath="${partialpath}/${dir}"
            if [ ! -d "$partialpath" ]; then
                mkdir "$partialpath"
                local rc="$?"
                if [ "$rc" -ne 0 ]; then
                    echo "Error when trying to create directory $path. Exit code: $rc"
                    exit 1
                fi
                if [ "${partialpath%/}" == "${path%/}" ]; then
                    :
                else
                    chmod $interperm "$partialpath"
                fi
            fi
        fi
    done
}

copy_files() {
    # $1 Source path
    # $2 Dest path
    # $3 Optional flags

    local source_path="$1"
    local dest_path="$2"
    local flags="$3"

    if [ -n "$flags" ]; then
        cp $flags $source_path $dest_path
    else
        cp $source_path $dest_path
    fi

    local rc="$?"
    if [ "$rc" -ne 0 ]; then
        echo "Failed to copy $source_path to $dest_path. Exit code: $rc"
        exit 4
    fi
}

touch_file() {
    # $1 Filepath

    local filepath="$1"

    touch $filepath

    local rc="$?"
    if [ "$rc" -ne 0 ]; then
        if [ -z "$OLD_NOTEBOOK_EXEC_USER" ]; then
            echo "Failed to touch file $filepath. Exit code: $rc"
            exit 8
        else
            echo "$IBM_PLATFORM_DEPLOY_HOOK_EXEC_USER is not the file owner of $(dirname $filepath)."\
            "Manually change $IBM_PLATFORM_DEPLOY_HOOK_EXEC_USER as the owner of $(dirname $filepath)"\
            "or specify a new Notebook base data directory and retry the deployment."
            exit 8
        fi
    fi
}

remove_files() {
    # $1 Path
    # $2 Optional flags

    local path="$1"
    local flags="$2"
    
    if [ -n "$flags" ]; then
        rm $flags $path
    else
        rm $path
    fi
    
    local rc="$?"
    if [ "$rc" -ne 0 ]; then
        echo "Failed to remove $path. Exit code: $rc"
        exit 7
    fi
}

setfacl_user_command() {
    # $1 Username
    # $2 Permission string (i.e. "rwx")
    # $3 Path
    # $4 Optional Flags

    local username="$1"
    local permission="$2"
    local path="$3"
    local flags="$4"

    setfacl $flags u:$username:$permission $path

    local rc="$?"
    if [ "$rc" -ne 0 ]; then
        #Don't fail outright, since we know setfacl does not work on NFS.
        #Check if the user exists
        if [ -z `id -u $username 2>/dev/null` ]; then
            echo "Failed to setfacl for $path. The user $username does not exist."
            exit 11
        fi
    fi
}

setfacl_mask_command() {
        # $1 Permission string (i.e. "rwx")
        # $2 Path
        # $3 Optional Flags

        local permission="$1"
        local path="$2"
        local flags="$3"

        setfacl $flags m:$permission $path

        local rc="$?"
        if [ "$rc" -ne 0 ]; then
            echo "Failed to setfacl mask for $path."
        fi
}

setfacl_group_command() {
    local permission="$1"
    local path="$2"
    local flags="$3"

    setfacl $flags g::$permission $path
    local rc="$?"
    if [ "$rc" -ne 0 ]; then
        echo "Failed to setfacl group for $path."
    fi
}

setfacl_other_command() {
    local permission="$1"
    local path="$2"
    local flags="$3"

    setfacl $flags o::$permission $path
    local rc="$?"
    if [ "$rc" -ne 0 ]; then
        echo "Failed to setfacl other for $path."
    fi
}

is_ok_to_use_deploy_home() {
    if [ ! -e "$NOTEBOOK_DEPLOY_DIR" ]; then
        #Path does not exist, ok to use it
        echo 0
    else
        if [ ! -d "$NOTEBOOK_DEPLOY_DIR" ]; then
            #The path is a file, not a directory, we can't deploy to it
            echo 1
        else
            if [ -e "$NOTEBOOK_DEPLOY_DIR/$CREATED_BY_CONDUCTOR_FOR_SPARK_FILE" ]; then
                #The .uuid file exists, the directory belongs to this Spark instance group
                echo 0
            else
                #The directory exists, but the .uuid file does not exist
                if [ $(find "$NOTEBOOK_DEPLOY_DIR" -maxdepth 0 -type d -empty 2>/dev/null) ]; then
                    #The directory is empty, it is OK to use it
                    echo 0
                else
                    #The directory is not empty, check what it contains
                    if [ -d "$NOTEBOOK_SERVICELOGS_DIR" ]; then
                        #The service_logs directory exists, check if there is anything else
                        if [ $(find "$NOTEBOOK_DEPLOY_DIR" -maxdepth 1 ! -name service_logs | wc -l) -eq 1 ]; then
                            #The service_logs directory is the only thing in the dir, it is OK to use it
                            echo 0
                        else
                            #There are other files in the directory aside from the service_logs directory
                            #We can't deploy to it
                            echo 1
                        fi
                    else
                        #The service_logs directory does not exist, so the directory must have other contents
                        #We can't deploy to it
                        echo 1
                    fi
                fi
            fi 
        fi
    fi
    
}

##########################
### Functional Methods ###
##########################

verify_notebook_deploy_dir_defined() {
    if [ -z "$NOTEBOOK_DEPLOY_DIR" ]; then
        echo "NOTEBOOK_DEPLOY_DIR is not defined."
        exit 7
    fi
}

clean_up_logs() {
    # Back up the service log files if the execution user for the service has changed
    # $1 file path
    # $2 file pattern
    # $3 new username

    local file_path="$1"
    local file_pattern="$2"
    local new_username="$3"

    if [ -n "$new_username" ]; then
        local files_matching_pattern=$(ls -ld ${file_path}/* | grep ${file_pattern} | grep -v ".old-" | awk '{print $9}')
        if [ ${#files_matching_pattern[@]} -ne 0 ]; then
            for f in ${files_matching_pattern[@]}
            do
                local old_username=$(ls -ld $f | awk '{print $3}')
                if [ "$old_username" != "$new_username" ]; then
                CONSUMER_USER_CHANGED=true
                mv $f $f.old-$old_username
                fi
            done
        fi
    fi
}

clean_up_all_service_logs() {
    if [ -n "$NOTEBOOK_CONSUMER_EXEC_USER" ]; then
        clean_up_logs $NOTEBOOK_SERVICELOGS_DIR "$APP_NAME-.*.log" $NOTEBOOK_CONSUMER_EXEC_USER
    fi
}

create_notebook_deploy_dir() {
    if [ ! -d "$NOTEBOOK_DEPLOY_DIR" ]; then
        make_directory_with_multilevel_permission $NOTEBOOK_DEPLOY_DIR 700 770
        setfacl_group_command "rwx" $NOTEBOOK_DEPLOY_DIR "-m"
        touch_file $NOTEBOOK_DEPLOY_DIR/$CREATED_BY_CONDUCTOR_FOR_SPARK_FILE
        if [ -n "$NOTEBOOK_CONSUMER_EXEC_USER" ]; then
            setfacl_user_command $NOTEBOOK_CONSUMER_EXEC_USER "rwx" $NOTEBOOK_DEPLOY_DIR "-m"
        fi
    elif [ $(is_ok_to_use_deploy_home) -eq 0 ]; then
        if [ -e "$NOTEBOOK_DEPLOY_DIR/$CREATED_BY_CONDUCTOR_FOR_SPARK_FILE" ]; then
            remove_files $NOTEBOOK_DEPLOY_DIR/$CREATED_BY_CONDUCTOR_FOR_SPARK_FILE
        fi
        touch_file $NOTEBOOK_DEPLOY_DIR/$CREATED_BY_CONDUCTOR_FOR_SPARK_FILE
        if [ -n "$NOTEBOOK_CONSUMER_EXEC_USER" ]; then
            setfacl_user_command $NOTEBOOK_CONSUMER_EXEC_USER "rwx" $NOTEBOOK_DEPLOY_DIR "-m"
        fi
    else
        echo "The notebook deployment directory ${NOTEBOOK_DEPLOY_DIR} already exists and does not belong to the Spark instance group with the ID $APP_UUID."
        exit 3
    fi
}

create_notebook_base_dir() {
    # check whether current user has enough write and read permission to NOTEBOOK_DATA_BASE_DIR
    if [ -d "$NOTEBOOK_DATA_BASE_DIR" ]; then
        # check write permission
        touch_file ${NOTEBOOK_DATA_BASE_DIR}/temp.txt
        rm -f ${NOTEBOOK_DATA_BASE_DIR}/temp.txt
    else
        make_directory_with_multilevel_permission $NOTEBOOK_DATA_BASE_DIR 700 770
        setfacl_group_command "rwx" $NOTEBOOK_DATA_BASE_DIR "-m" 
    fi

    setfacl_user_command $IBM_PLATFORM_DEPLOY_HOOK_EXEC_USER "rwx" $NOTEBOOK_DATA_BASE_DIR "-d -m"
    setfacl_group_command "---" "$NOTEBOOK_DATA_BASE_DIR" "-d -m"
    
    if [ -n "$NOTEBOOK_CONSUMER_EXEC_USER" ]; then
        setfacl_user_command $NOTEBOOK_CONSUMER_EXEC_USER "rwx" $NOTEBOOK_DATA_BASE_DIR "-m"
    else
        setfacl_user_command $IBM_PLATFORM_DEPLOY_HOOK_EXEC_USER "rwx" $NOTEBOOK_DATA_BASE_DIR "-m"
    fi

    if [ ! -d "$JUPYTER_DATA_DIR" ]; then
        make_directory_with_multilevel_permission $JUPYTER_DATA_DIR 700 770
        chmod 770 $JUPYTER_DATA_DIR
    else
        # check write permission
        touch_file ${JUPYTER_DATA_DIR}/temp.txt
        rm -f ${JUPYTER_DATA_DIR}/temp.txt
    fi

    setfacl_user_command $IBM_PLATFORM_DEPLOY_HOOK_EXEC_USER "rwx" $JUPYTER_DATA_DIR "-d -m"

    if [ -n "$NOTEBOOK_CONSUMER_EXEC_USER" ]; then
        setfacl_user_command $NOTEBOOK_CONSUMER_EXEC_USER "rwx" "$NOTEBOOK_DATA_BASE_DIR/${APP_NAME}" "-m"
        setfacl_user_command $NOTEBOOK_CONSUMER_EXEC_USER "rwx" $JUPYTER_DATA_DIR "-m"
    else
        setfacl_user_command $IBM_PLATFORM_DEPLOY_HOOK_EXEC_USER "rwx" $JUPYTER_DATA_DIR "-m"
    fi
}

copy_scripts_dir () {
    old_umask=`umask`
    umask 027
    copy_files ./scripts $NOTEBOOK_DEPLOY_DIR/ "-r"
    setfacl_group_command "r-x" "$NOTEBOOK_DEPLOY_DIR/scripts" "-R -m"
    umask $old_umask
    find ./scripts/* ! -name deploy.sh ! -name undeploy.sh ! -name *.inc -exec rm -f {} \;
}

copy_buildinfo_file() {
    if [ ! -e "./build.version" ]; then
        return
    fi
    old_umask=`umask`
    umask 027
    copy_files ./build.version $NOTEBOOK_DEPLOY_DIR/
    umask $old_umask
}

install_jupyter_using_anaconda() {
    if [ -z "${NOTEBOOK_DEPLOY_DIR}" ] || [ -z "${ANACONDA_SCRIPT_NAME}" ]; then
        return
    fi
    old_umask=`umask`
    umask 027
    copy_files ./package/$ANACONDA_SCRIPT_NAME $NOTEBOOK_DEPLOY_DIR/
    bash $NOTEBOOK_DEPLOY_DIR/$ANACONDA_SCRIPT_NAME -b -p $INSTALLDIR
    rc=$?
    umask $old_umask
    if [ "$rc" -ne 0 ]; then
        echo "Failed to run anaconda setup."
        exit 5
    fi
    setfacl_group_command "r-x" "$INSTALLDIR" "-R -d -m"
    setfacl_group_command "r-x" "$INSTALLDIR" "-R -m"
    
    rm -rf $NOTEBOOK_DEPLOY_DIR/$ANACONDA_SCRIPT_NAME
}

generate_jupyter_config() {
    export JUPYTER_CONFIG_DIR=$NOTEBOOK_DEPLOY_DIR/scripts/
    ${conda_env_bin_path}jupyter notebook --generate-config
    setfacl_group_command "r-x" "$NOTEBOOK_DEPLOY_DIR/scripts/jupyter_notebook_config.py" "-m"
}

generate_jupyter_enterprise_gateway_config() {
    export JUPYTER_CONFIG_DIR=$NOTEBOOK_DEPLOY_DIR/scripts/
    ${conda_env_bin_path}jupyter-enterprisegateway --generate-config -y
    setfacl_group_command "r-x" "$NOTEBOOK_DEPLOY_DIR/scripts/jupyter_enterprise_gateway_config.py" "-m"
}

enable_jupyter_serverextension() {
   local packagename=$1
   ${conda_env_bin_path}jupyter serverextension enable --py $packagename --sys-prefix
}

install_jupyter_enterprise_gateway() {
    if [ "${JEG_ENABLED}" != "TRUE" ] || [ -z "${NOTEBOOK_DEPLOY_DIR}" ]; then
       return
    fi

    INSTALLED_VERSION=`${conda_env_bin_path}jupyter notebook --version`
    $(is_version_equal_or_greater "${INSTALLED_VERSION}" "5.4.0")
    if [ $? -ne 0 ]; then
        return
    fi
    old_umask=`umask`
    umask 002
    copy_files ./package/${JEG_PACKAGE} $NOTEBOOK_DEPLOY_DIR/
    cd $NOTEBOOK_DEPLOY_DIR
    tar xvf ${JEG_PACKAGE}
    if [ "$?" -ne 0 ]; then
        echo "Failed to extract package."
        exit 12
    fi
    
    ${conda_env_bin_path}pip install ${JEG_INSTALL_PACKAGE_NAME} --no-cache-dir --no-index --find-links="${NOTEBOOK_DEPLOY_DIR}/${JEG_PACKAGE_DIR}/"
    if [ "$?" -ne 0 ]; then
        echo "Failed to install JEG. Ensure the conda environment used for the notebook contains prerequisite standard libraries to install Jupyter Enterprise Gateway."
        exit 15
    fi

    ${conda_env_bin_path}pip install ${NB2KG_INSTALL_PACKAGE_NAME} --no-cache-dir --no-index --find-links="${NOTEBOOK_DEPLOY_DIR}/${JEG_PACKAGE_DIR}/"
    if [ "$?" -ne 0 ]; then
        echo "Failed to install NB2KG. Ensure the conda environment used for the notebook contains prerequisite standard libraries to install Notebook-To-Kernel-Gateway."
        exit 16
    fi
    
    generate_jupyter_enterprise_gateway_config
    if [ "$?" -ne 0 ]; then
        echo "Failed to generate JEG config"
        exit 17
    fi
    enable_jupyter_serverextension "nb2kg"
    if [ "$?" -ne 0 ]; then
        echo "Failed to enable NB2KG extension"
        exit 18
    fi
    
    # Handle Python3 Anaconda
    KERNEL_DIR="$(${conda_env_bin_path}jupyter kernelspec list | grep -w "python3" | awk '{print $2; exit}')"
    KERNELS_FOLDER="$(dirname "${KERNEL_DIR}")"
    if [ -n "$KERNEL_DIR" ]; then
        copy_files "${NOTEBOOK_DEPLOY_DIR}/${JEG_PACKAGE_DIR}/kernelspec/." "$KERNELS_FOLDER" "-r"
        chmod 755 -R "$KERNELS_FOLDER"
    fi
    
    # Handle Python2 Anaconda
    KERNEL_DIR="$(${conda_env_bin_path}jupyter kernelspec list | grep -w "python2" | awk '{print $2; exit}')"
    KERNELS_FOLDER="$(dirname "${KERNEL_DIR}")"
    if [ -n "$KERNEL_DIR" ]; then
        copy_files "${NOTEBOOK_DEPLOY_DIR}/${JEG_PACKAGE_DIR}/kernelspec/." "$KERNELS_FOLDER" "-r"
        chmod 755 -R "$KERNELS_FOLDER"
    fi

    umask $old_umask
    # Cleanup runtime directory during JEG config generation 
    if [ -d "${JUPYTER_DATA_DIR}/runtime" ]; then
        rm -rf ${JUPYTER_DATA_DIR}/runtime
    fi
    rm -rf ${NOTEBOOK_DEPLOY_DIR}/${JEG_PACKAGE_DIR}*
}

copy_loginegoauth() {
    PY_VERSION=`python -V 2>&1 | awk -F' ' '{print $2}' | cut -c1,2,3`
    old_umask=`umask`
    umask 027
    SITE_PACKAGE_PATH=`find ${conda_env_path} -name "*site-package*" | grep $PY_VERSION`
    copy_files $NOTEBOOK_DEPLOY_DIR/scripts/loginegoauth.py $SITE_PACKAGE_PATH/notebook/auth/
    copy_files $NOTEBOOK_DEPLOY_DIR/scripts/loginegoauth.html $SITE_PACKAGE_PATH/notebook/templates/
    umask $old_umask
}

disable_jupyter_terminal(){
    # Need to export the proper home to deployment user else conda will fail
    OLD_HOME=$HOME
    user=`whoami`
    export HOME=$(eval echo ~$user)
    # Uninstall terminado package to disable terminal, suppress all output from uninstallation
    echo "Disabling Jupyter notebook terminal."
    ${conda_env_bin_path}pip uninstall -y --no-cache-dir terminado > /dev/null 2>&1
    ${conda_env_bin_path}conda remove --force --offline terminado > /dev/null 2>&1
    export HOME=$OLD_HOME
}

copy_filemanager_py(){
    INSTALLED_VERSION=`${conda_env_bin_path}jupyter notebook --version`
    $(is_version_equal_or_greater "${INSTALLED_VERSION}" "5.5.0")
    if [ $? -eq 0 ]; then
        # Send2Trash opensource fixed notebook removal after 5.4.0. If notebook version is above or equal 5.5.0, do not need to patch.
        return
    fi
    old_umask=`umask`
    umask 027
    SITE_PACKAGE_PATH=`find ${conda_env_path} -name "*site-package*" | awk '{print $1; exit}'`
    copy_files $NOTEBOOK_DEPLOY_DIR/scripts/filemanager.py $SITE_PACKAGE_PATH/notebook/services/contents/
    umask $old_umask
}

create_service_logs_dir() {
    #Make service_logs dir
    if [ ! -d "$NOTEBOOK_SERVICELOGS_DIR" ]; then
        make_directory_with_multilevel_permission $NOTEBOOK_SERVICELOGS_DIR 700 770
    fi
    setfacl_user_command $IBM_PLATFORM_DEPLOY_HOOK_EXEC_USER "rwx" $NOTEBOOK_SERVICELOGS_DIR "-d -m"
    if [ -n "$NOTEBOOK_CONSUMER_EXEC_USER" ]; then
        setfacl_user_command $NOTEBOOK_CONSUMER_EXEC_USER "rwx" $NOTEBOOK_SERVICELOGS_DIR "-m"
    else
        setfacl_user_command $IBM_PLATFORM_DEPLOY_HOOK_EXEC_USER "rwx" $NOTEBOOK_SERVICELOGS_DIR "-m"
    fi
}

deploy_new_jupyter_notebook() {
    echo "Deploy Jupyter notebook to $NOTEBOOK_DEPLOY_DIR"
    create_notebook_deploy_dir
    create_notebook_base_dir
    create_service_logs_dir
    copy_scripts_dir
    copy_buildinfo_file
    if [ "$decoupled" != "true" ]; then
        install_jupyter_using_anaconda
    fi
    generate_jupyter_config
    install_jupyter_enterprise_gateway
    copy_loginegoauth
    if [ "${DISABLE_TERMINAL}" = "TRUE" ]; then
        disable_jupyter_terminal
    fi
    copy_filemanager_py
}

deploy_updated_jupyter_notebook() {
    echo "NOTEBOOK_UPDATE_PACKAGE=true. Updating Jupyter notebook."   
    create_notebook_deploy_dir
    create_notebook_base_dir
    create_service_logs_dir
    copy_scripts_dir
    copy_buildinfo_file
    if [ "$decoupled" != "true" ]; then
        install_jupyter_using_anaconda
    fi
    generate_jupyter_config
    install_jupyter_enterprise_gateway
    copy_loginegoauth
    if [ "${DISABLE_TERMINAL}" = "TRUE" ]; then
        disable_jupyter_terminal
    fi
    copy_filemanager_py
}

redeploy_jupyter_notebook_for_major_config_change() {
    deploy_new_jupyter_notebook
}

redeploy_jupyter_notebook_for_minor_config_change() {
    if [ $(is_ok_to_use_deploy_home) -ne 0 ]; then
        echo "The notebook deployment directory $NOTEBOOK_DEPLOY_DIR exists and does not belong to the Spark instance group with ID $APP_UUID."
        exit 3
    fi
    clean_up_all_service_logs
    create_notebook_base_dir
    create_service_logs_dir
    
    JEG_INSTALLED_VERSION=`${conda_env_bin_path}jupyter enterprisegateway --version > /dev/null 2>&1`
    if [ "$?" -ne 0 ]; then
        install_jupyter_enterprise_gateway
        copy_loginegoauth
        if [ "${DISABLE_TERMINAL}" = "TRUE" ]; then
            disable_jupyter_terminal
        fi
        copy_filemanager_py
    fi
}

deploy_jupyter_if_available() {
    if [ "$decoupled" = "true" ] || [ -e "./package/$ANACONDA_SCRIPT_NAME" ]; then
        if [ -z "$OLD_NOTEBOOK_DEPLOY_DIR" ] && [ -z "$OLD_NOTEBOOK_EXEC_USER" ]; then
            if [ ! -f "${NOTEBOOK_DEPLOY_DIR}/scripts/common.inc" ]; then
                echo "Notebook deployment directory not found. Deploy new notebook."
                deploy_new_jupyter_notebook
            else
                echo "Notebook deployment directory exists. Update notebook."
                NOTEBOOK_UPDATE_PACKAGE=true
                cleanup_notebook_deployment
                deploy_updated_jupyter_notebook
            fi
        else
            echo "Redeploy notebook to new deploy directory."
            if [ -f "${NOTEBOOK_DEPLOY_DIR}/scripts/common.inc" ]; then
                cleanup_notebook_deployment
            fi
            redeploy_jupyter_notebook_for_major_config_change
        fi
    else
        echo "Anaconda script does not exist. Update notebook configuration."
        redeploy_jupyter_notebook_for_minor_config_change
    fi  

}

update_timestamp_file() {
    if [ -n "$LAST_UPDATED_TIMESTAMP" ]; then
        if [ -e "$LAST_UPDATE_TIMESTAMP_FILE" ]; then
            local current_timestamp=`head -n 1 $LAST_UPDATE_TIMESTAMP_FILE`
            if [ "$LAST_UPDATED_TIMESTAMP" -ne "$current_timestamp" ]; then
                echo "$LAST_UPDATED_TIMESTAMP" > $LAST_UPDATE_TIMESTAMP_FILE
                if [ "$?" -ne 0 ]; then
                    echo "Failed to update the timestamp in $LAST_UPDATE_TIMESTAMP_FILE."
                    exit 14
                fi
                setfacl_group_command "r--" "$LAST_UPDATE_TIMESTAMP_FILE" "-m"
            fi
        else
            echo "$LAST_UPDATED_TIMESTAMP" > $LAST_UPDATE_TIMESTAMP_FILE
            if [ "$?" -ne 0 ]; then
                echo "Failed to update the timestamp in $LAST_UPDATE_TIMESTAMP_FILE."
                exit 14
            fi
            setfacl_group_command "r--" "$LAST_UPDATE_TIMESTAMP_FILE" "-m"
        fi
    fi  
}

main() {
    verify_notebook_deploy_dir_defined
    source_conda_environment
    if [ "$decoupled" = "true" ]; then
        INSTALLED_VERSION=`${conda_env_bin_path}jupyter notebook --version`
        if [ "$?" -ne 0 ]; then
            echo "Failed to get Jupyter notebook version. Ensure Jupyter notebook exist and properly installed in the notebook conda environment."
            exit 19
        fi
    fi
    if [ -z "$NOTEBOOK_UPDATE_PARAMETER" ] && [ -z "$NOTEBOOK_UPDATE_PACKAGE" ] && [ -z "$ASCD_DEPLOY_SINGLE_HOST" ]; then
        deploy_new_jupyter_notebook
    elif [ -n "$ASCD_DEPLOY_SINGLE_HOST" ]; then
        deploy_jupyter_if_available
    elif [ -n "$NOTEBOOK_UPDATE_PACKAGE" ]; then
        deploy_updated_jupyter_notebook
    elif [ -n "$NOTEBOOK_UPDATE_PARAMETER" ]; then
        if [ -z "$OLD_NOTEBOOK_DEPLOY_DIR" ] && [ -z "$OLD_NOTEBOOK_EXEC_USER" ]; then
            if [ ! -f "${NOTEBOOK_DEPLOY_DIR}/scripts/common.inc" ]; then
                echo "Notebook deployment directory not found. Redeploying Notebook."
                deploy_new_jupyter_notebook
            else
                redeploy_jupyter_notebook_for_minor_config_change
            fi
        else
            echo "Redeploy to new deploy directory."
            redeploy_jupyter_notebook_for_major_config_change
        fi  
    fi
    
    #Always check if timestamp should be updated as last step in the deployment
    update_timestamp_file
    unsource_conda_environment
}

main "$@"
