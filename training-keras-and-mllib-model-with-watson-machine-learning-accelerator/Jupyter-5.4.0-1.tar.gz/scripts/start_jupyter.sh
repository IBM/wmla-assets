#!/bin/bash

source ${NOTEBOOK_DEPLOY_DIR}/scripts/common.inc
source ${NOTEBOOK_DEPLOY_DIR}/scripts/jupyter.inc

: 'Exit codes:
    1 - Failed to create directory
    2 - Spark master URL not found
    3 - Failed to authenticate
    4 - Error decrypting password
    5 - Open SSL error
    6 - Failed to retrieve SSL information
    7 - ASCD_REST_CACERT_PATH not defined
    8 - ASCD_REST_CACERT_PATH does not exist
    9 - Directory is not defined
    10 - Directory already exists
    11 - Failed to write to base data dir
    12 - Failed to start JEG
    13 - No such SSL protocol
    
    RESERVED ERROR CODES - Will cause service to block
    17 - Failed to start command (EGO code)
    25 - Failed to create stdout/stderr redirection files (EGO code)
    99 - Local timestamp does not match service timestamp
'

while [ -n "$1" ]; do
    if  expr $1 : "--disable_terminal" > /dev/null
    then
        export DISABLE_TERMINAL=$2
    fi
    shift
done

declare -r DEFAULT_CULL_IDLE_TIMEOUT=3600            # Default to cull kernel if idles for 1 hours without kernel connection.
declare -r DEFAULT_CULL_INTERVAL=600                 # Default for periodic poll to check kernel status.
declare -r DEFAULT_CULL_CONNECTED="False"            # Default do not cull kernel if has connection.
declare -r DEFAULT_CULL_BUSY="False"                 # Default do not cull kernel if kernel is busy.
declare -r DEFAULT_JEG_LOG_LEVEL="INFO"              # Default JEG log level
declare -r DEFAULT_JEG_KERNEL_START_TIMEOUT=300      # Default JEG kernel startup timeout
declare -r DEFAULT_NB2KG_REQUEST_TIMEOUT=400         # Default NB2KG <-> JEG communication request timeout
declare -r DEFAULT_SSL_PROTOCOL="PROTOCOL_TLSv1_2"   # Default SSL_PROTOCOL for Jupyter notebook server
declare -r SSL_PROTOCOLS=("PROTOCOL_SSLv2" "PROTOCOL_SSLv3" "PROTOCOL_SSLv23" "PROTOCOL_TLSv1" "PROTOCOL_TLSv1_1" "PROTOCOL_TLSv1_2")   # List of SSL protocols
#######################
### Utility Methods ###
#######################
make_directory_with_multilevel_permission() {
    # $1 Directory path
    # $2 Optional destination directory permissions
    # $3 Optional intermediate directory permissions (multilevel directory)
    local path="$1"
    local destperm="$2"
    local interperm="$3"

    if [ -z "$path" ]; then
        echo_log "Directory is not defined"
        exit 9
    fi

    if [ -d "$path" ]; then
        echo_log "$path already exists"
        exit 10
    fi
    
    #remove extra slashes in the path
    path=$(sed 's/\/\+/\//g'<<<"$path")
    
    IFS=/
    array=($path)
    unset IFS
    partialpath=""

    for dir in "${array[@]}"; do
        if [ -n "$dir" ]; then
            partialpath="${partialpath}/${dir}"
            if [ ! -d "$partialpath" ]; then
                mkdir "$partialpath"
                local rc="$?"
                if [ "$rc" -ne 0 ]; then
                    echo_log "Error when trying to create directory $path. Exit code: $rc"
                    exit 1
                fi
                if [ "${partialpath%/}" == "${path%/}" ]; then
                    :
                else
                    chmod $interperm "$partialpath"
                fi
            fi
        fi
    done
}


#allow non-root user to launch a jupyter notebook
unset XDG_RUNTIME_DIR

# source the conda environment
source_conda_environment

#Create base data directory if it does not already exist
#Ensure user has permission to write to the directory
if [ ! -d "$NOTEBOOK_DATA_DIR" ]; then
    make_directory_with_multilevel_permission ${NOTEBOOK_DATA_DIR} 700 770
fi

if [ ! -d "$LOGDIR" ]; then
    make_directory_with_multilevel_permission $LOGDIR 700 770
fi
#restore the history log file with timestamp
if [ -f $LOGFILE ]; then
    mv $LOGFILE $LOGDIR/ipython_`date +%Y%m%d_%H%M`.log
fi


touch $LOGFILE
echo_log "Logging to $LOGFILE"
echo_log_to_file "Entered" $LOGFILE

#Check timestamp first to ensure notebook deployment is up to date
validate_timestamp

rm -rf ${PORT_FILE}
rc="$?"
if [ "$rc" -ne 0 ]; then
    echo_log "The user `whoami` does not have write access to existing files in the notebook base data directory $NOTEBOOK_DATA_DIR. If the notebook's consumer was modified, contact your cluster administrator to grant ownership of this notebook's data to the new consumer execution user or to correct the consumer in the Spark instance group configuration."
    exit 11
fi
touch ${PORT_FILE}

#Handle extra conf if specified
source "${SPARK_HOME}"/conf/spark-env.sh

if [ -n "$SPARK_EGO_CONF_DIR_EXTRA" ]; then
    if [ -f "${SPARK_EGO_CONF_DIR_EXTRA}/spark-env.sh" ]; then
      source "${SPARK_EGO_CONF_DIR_EXTRA}"/spark-env.sh
    fi
else
    echo_log_to_file "no extra configuration defined" $LOGFILE
fi

if [ -n "$NOTEBOOK_EXTRA_CONF_FILE" ]; then
        if [ -e $NOTEBOOK_EXTRA_CONF_FILE ]; then
                source $NOTEBOOK_EXTRA_CONF_FILE
        else
            echo_log_to_file "Extra configuration file $NOTEBOOK_EXTRA_CONF_FILE does not exist. Starting notebook with default configurations" $LOGFILE
        fi
fi

if [ -n "$PYSPARK_PYTHON" ]; then
    echo_log_to_file "PYSPARK_PYTHON is defined" $LOGFILE
    export PYSPARK_PYTHON=$PYSPARK_PYTHON
else
    if [ "$decoupled" = "true" ]; then
        export PYSPARK_PYTHON=${conda_env_path}bin/python
    else
        export PYSPARK_PYTHON=$NOTEBOOK_DEPLOY_DIR/install/bin/python
    fi
    echo_log_to_file "PYSPARK_PYTHON is not defined" $LOGFILE
fi

if [ "$decoupled" = "true" ]; then
    export PYSPARK_DRIVER_PYTHON=${conda_env_path}bin/python
else
    export PYSPARK_DRIVER_PYTHON=$NOTEBOOK_DEPLOY_DIR/install/bin/jupyter
fi

export IPYTHONDIR=$DATADIR/ipydir
export JUPYTER_CONFIG_DIR=$NOTEBOOK_DATA_DIR/config
export JUPYTER_NOTEBOOK_DIR=$NOTEBOOK_DATA_DIR/notebooks

#when restart service, update all the config files
if [ -d "$JUPYTER_DATA_DIR" ]; then
    rm -rf $JUPYTER_DATA_DIR
fi

if [ -d "$JUPYTER_CONFIG_DIR" ]; then
    rm -rf $JUPYTER_CONFIG_DIR
fi

if [ -d "$IPYTHONDIR" ]; then
    rm -rf $IPYTHONDIR
fi

if [ ! -d "$JUPYTER_CONFIG_DIR" ]; then
    make_directory_with_multilevel_permission $JUPYTER_CONFIG_DIR 700 770
fi
cp ./scripts/jupyter_notebook_config.py $JUPYTER_CONFIG_DIR

if [ "${JEG_ENABLED}" == "TRUE" ]; then
    cp ./scripts/jupyter_enterprise_gateway_config.py $JUPYTER_CONFIG_DIR
fi

if [ ! -d "$JUPYTER_CONFIG_DIR/custom" ]; then
    make_directory_with_multilevel_permission $JUPYTER_CONFIG_DIR/custom 700 770
fi
cp ./scripts/custom.js $JUPYTER_CONFIG_DIR/custom/
if [ ! -d "$JUPYTER_DATA_DIR" ]; then
    make_directory_with_multilevel_permission $JUPYTER_DATA_DIR 700 770
fi
if [ ! -d "$JUPYTER_DATA_DIR/runtime" ]; then
    // Pre-create the runtime directory. To allow impersonated user to create connection files under JUPYTER_DATA_DIR
    make_directory_with_multilevel_permission "$JUPYTER_DATA_DIR/runtime" 700 770
    setfacl -m g::-wx "$JUPYTER_DATA_DIR/runtime"
    setfacl -m o::-wx "$JUPYTER_DATA_DIR/runtime"
    chmod +t "$JUPYTER_DATA_DIR/runtime"
fi
if [ ! -d "$IPYTHONDIR/profile_default/startup" ]; then
    make_directory_with_multilevel_permission $IPYTHONDIR/profile_default/startup 700 770
fi
cp ./scripts/00-pyspark-setup.py $IPYTHONDIR/profile_default/startup/
cp ./scripts/01-defaultfs-setup.py $IPYTHONDIR/profile_default/startup/
if [ ! -d "$JUPYTER_NOTEBOOK_DIR" ]; then
    make_directory_with_multilevel_permission $JUPYTER_NOTEBOOK_DIR 700 770
fi

IPYTHON_LIB_PATH=`find $conda_env_path -name "*site-package*" | awk '{print $1; exit}'`

export PYTHONPATH="$IPYTHON_LIB_PATH: ${PYTHONPATH}"

cd $JUPYTER_CONFIG_DIR


# Set default Jupyter notebook server SSL protocol if not it is not set
if [ -z "${SSL_PROTOCOL}" ]; then
    SSL_PROTOCOL="${DEFAULT_SSL_PROTOCOL}"
fi

CONFIG_FILE=jupyter_notebook_config.py

sed -i "s,#\s*c.NotebookApp.ip =.*$,c.NotebookApp.ip = '0.0.0.0',g" $CONFIG_FILE
sed -i "s,c.NotebookApp.ip =.*$,c.NotebookApp.ip = '0.0.0.0',g" $CONFIG_FILE
sed -i "s,#\s*c.NotebookApp.open_browser =.*$,c.NotebookApp.open_browser = False,g" $CONFIG_FILE
sed -i "s,c.NotebookApp.open_browser =.*$,c.NotebookApp.open_browser = False,g" $CONFIG_FILE
sed -i "s,#\s*c.NotebookApp.port_retries =.*$,c.NotebookApp.port_retries = 1000,g" $CONFIG_FILE
sed -i "s,c.NotebookApp.port_retries =.*$,c.NotebookApp.port_retries = 1000,g" $CONFIG_FILE
sed -i "s,#\s*c.NotebookApp.login_handler_class =.*$,c.NotebookApp.login_handler_class = 'notebook.auth.loginegoauth.EgoLoginHandler',g" $CONFIG_FILE
sed -i "s,c.NotebookApp.login_handler_class =.*$,c.NotebookApp.login_handler_class = 'notebook.auth.loginegoauth.EgoLoginHandler',g" $CONFIG_FILE
sed -i "s,#\s*c.KernelManager.autorestart =.*$,c.KernelManager.autorestart = False,g" $CONFIG_FILE
sed -i "s,c.KernelManager.autorestart =.*$,c.KernelManager.autorestart = False,g" $CONFIG_FILE

echo_log_to_file "export SPARK_HOME=$SPARK_HOME" $LOGFILE
export SPARK_HOME=$SPARK_HOME
one_notebook_master_url="one_notebook_master_url"
one_notebook_master_rest_url="one_notebook_master_rest_url"
one_notebook_master_web_submission_url="one_notebook_master_web_submission_url"
activedataconnectors="activedataconnectors"
defaultfsdataconnector="defaultfsdataconnector"
notebookcookieprefix="cookie_notebook"
notebookcookieegoprefix="cookie_notebook_ego"

#MASTER
if [ -n "$CONDUCTOR_REST_URL" ]; then
    last_char=${CONDUCTOR_REST_URL: -1}
    if [ "${last_char}" != "/" ]; then
       CONDUCTOR_REST_URL=${CONDUCTOR_REST_URL}"/"
    fi
    
    if [[ "$CONDUCTOR_REST_URL" == https://* ]]; then
        #ASCD is SSL enabled - Need to user the cacert for REST calls to ASCD
        if [ -z "$ASCD_REST_CACERT_PATH" ]; then
            echo_log_to_file "The ASCD_REST_CACERT_PATH is not defined. This value is required to connect to ascd REST service using https." $LOGFILE
            exit 7
        else
            #First resolve any environment variables in the path
            ASCD_REST_CACERT_PATH=`eval echo $ASCD_REST_CACERT_PATH`
            if [ ! -f $ASCD_REST_CACERT_PATH ]; then
                echo_log_to_file "The CA Certificate $ASCD_REST_CACERT_PATH does not exist. This file is required to connect to ascd REST service using https." $LOGFILE
                exit 8
            fi
            
            curlSecureOpt="--cacert $ASCD_REST_CACERT_PATH"
        fi
    else
        curlSecureOpt="-k"
    fi
fi

#For Dockerized case - determine SERVICE_ascd_LOCATION value by cycling through hosts in EGO_MASTER_LIST_PEM
if [ "$SERVICE_ascd_LOCATION" == "\${SERVICE_ascd_LOCATION}" -o ! -n "$SERVICE_ascd_LOCATION" ]; then
    if [ -n "${EGO_MASTER_LIST_PEM}" ]; then
        egoMasterListPem=$(echo $EGO_MASTER_LIST_PEM | tr "," "\n")
        for SERVICE_ascd_LOCATION in $egoMasterListPem; do
            tmpConductorRestUrl=${CONDUCTOR_REST_URL//\$\{SERVICE_ascd_LOCATION\}/$SERVICE_ascd_LOCATION}
            testOutput=`curl $curlSecureOpt -XGET ${tmpConductorRestUrl}conductor/instances`
            if [ $? -eq 0 ]; then
                CONDUCTOR_REST_URL=$tmpConductorRestUrl
                break
            fi
        done
    fi
fi

export MANAGEMENT_HOST_LIST=$SERVICE_ascd_LOCATION

do_logon() {
    COUNTER=0
    SLEEP_INTERVAL=3
    while [ true ]; do
        csrfStr=`curl $curlSecureOpt -c ${DATADIR}/$2.$$ -XGET -H'Accept: application/json' -H"Authorization: PlatformToken token=$EGO_SERVICE_CREDENTIAL" $1 ${tlsVersion}`
        
        #If the REST service isn't up yet, nothing will come back in the csrfStr, continue looping until REST service is up
        if [ -z "$csrfStr" ]; then
            COUNTER=$(($COUNTER + 1 ))
            #Log a message every 30 seconds to help debugability in the event that REST service is not available
            if [ $(( $COUNTER % 10 )) -eq 0 ]; then
                echo_log_to_file "Unable to connect to the ascd REST service $1 after $(($COUNTER*$SLEEP_INTERVAL)) seconds." $LOGFILE
            fi
            sleep $SLEEP_INTERVAL
            continue
        fi
        
        #If csrfStr has content it means the call connected and returned something, try to parse it for the real token {"csrftoken":"...."}
        csrfArr=($(echo $csrfStr | sed "s/[{}:]/ /g"))
        arrLen=${#csrfArr[@]}
        csrfToken=`echo ${csrfArr[1]} | sed "s/\"//g"`
        if [ -z $csrfToken ] || [ "${arrLen}" != "2" ]; then
            if [ -n "$csrfStr" ]; then
                echo_log_to_file "$csrfStr" $LOGFILE $LOGFILE
            fi
            echo_log_to_file "$1 failed." $LOGFILE
            exit 3
        else
            echo_log_to_file "csrfStrToken got successfully" $LOGFILE
            break
        fi
    done
}

if [ -n "$CONDUCTOR_REST_URL" ]; then

    curlflag=`curl --help |grep tlsv1.2`
    if [ -n "$curlflag" ]; then
        tlsVersion="--tlsv1.2"
    else
        tlsVersion="--tlsv1"
    fi
    
    #Get a list of management hosts
    if [ -n "$EGO_REST_URL" ]; then
        last_char=${EGO_REST_URL: -1}
        if [ "${last_char}" != "/" ]; then
            EGO_REST_URL=${EGO_REST_URL}"/"
        fi
    
        tmpEgoRestUrl=${EGO_REST_URL//\$\{SERVICE_REST_LOCATION\}/$SERVICE_REST_LOCATION}
        
        do_logon "${tmpEgoRestUrl}ego/v1/auth/logon" ${notebookcookieegoprefix}
        
        mgmtHostList=""
        testOutput=`curl $curlSecureOpt -s -b ${DATADIR}/${notebookcookieegoprefix}.$$ -H'Accept:application/json' -H"Authorization: PlatformToken token=$EGO_SERVICE_CREDENTIAL" -X GET "${tmpEgoRestUrl}ego/v1/resourcegroups/ManagementHosts/members" ${tlsVersion}`
        if [ $? -eq 0 ]; then
            memberArr=($(echo $testOutput | sed "s/[][{}]//g" | awk -v k="text" '{n=split($0,a,","); for (i=1; i<=n; i++) print a[i]}'))
            arrLen=${#memberArr[@]}
            for i in "${memberArr[@]}"
            do
                itemArr=($(echo ${i} | sed "s/[\"]//g" | sed "s/[:]/ /g"))
                if [ "${itemArr[0]}" == "hostname" ]; then
                    if [ "${mgmtHostList}" != "" ]; then
                        mgmtHostList="${mgmtHostList},${itemArr[1]}"
                    else
                        mgmtHostList="${itemArr[1]}"
                    fi
                fi
            done
        fi
        if [ "${mgmtHostList}" != "" ]; then
            export MANAGEMENT_HOST_LIST=${mgmtHostList}
        fi
    fi
    
    do_logon "${CONDUCTOR_REST_URL}conductor/v1/auth/logon" ${notebookcookieprefix}

    retrialcount=0
    while [ $retrialcount -le 60 ]
    do
       output=`curl $curlSecureOpt -s -b ${DATADIR}/${notebookcookieprefix}.$$ -H'Accept:application/json' -X GET "${CONDUCTOR_REST_URL}conductor/v1/instances?id=${SPARK_INSTANCE_GROUP_UUID}&fields=outputs,connectors" ${tlsVersion}`
       # Parse out the master URL from the one_notebook_master_url output
       echo "${output}" |grep -qF "$one_notebook_master_url"
       if [ $? -ne 0 ]; then
           echo_log_to_file "The Spark notebook master URL was not found. Either the assigned user ${SPARK_EGO_USER} has no permission to access this Spark Instance Group, or the notebook master service is not started." $LOGFILE
           echo_log_to_file ${output} $LOGFILE
           exit 2
       fi
       masterurl=`echo ${output} | awk '{n=split($0,a,","); for (i=1; i<=n; i++) { if (a[i] ~ /one_notebook_master_url/) print a[i+1] }}' | awk '{n=split($0,a,":\""); print a[2]}' | tr "\"}" " "`
       masterurl=`echo $masterurl | xargs`

       #Spark Submission URL starts with spark://
       mastersubmissionurl=`echo ${output} | awk '{n=split($0,a,","); for (i=1; i<=n; i++) { if (a[i] ~ /one_notebook_master_rest_url/) print a[i+1] }}' | awk '{n=split($0,a,":\""); print a[2]}' | tr "\"}" " "`
       mastersubmissionurl=`echo $mastersubmissionurl | xargs`
       
       #Spark REST URL starts with http(s)://
       masterresturl=`echo ${output} | awk '{n=split($0,a,","); for (i=1; i<=n; i++) { if (a[i] ~ /one_notebook_master_web_submission_url/) print a[i+1] }}' | awk '{n=split($0,a,":\""); print a[2]}' | tr "\"}" " "`
       masterresturl=`echo $masterresturl | xargs`
        
       numcolon=`echo "${masterurl}" | awk -F':' '{print NF-1}'`
       if [ "${numcolon}" == "2" ]; then
            break
       fi
       sleep 3
       retrialcount=$(($retrialcount + 1 ))
    done

    # exit after max retrial to retrieve masterurl
    if [ $retrialcount -ge 61 ]; then
        echo_log_to_file "Notebook master url is not fetched successfully, please try restart notebook service or check if the notebook master service is alive" $LOGFILE
        exit 2
    fi
    
    # check SSL is enabled 
    if [ "${NOTEBOOK_SSL_ENABLED}" == "true" ]; then
        TIER=tier3
        sslBody=`curl $curlSecureOpt -s -b ${DATADIR}/${notebookcookieprefix}.$$ -H'Accept:application/json' -X GET "${CONDUCTOR_REST_URL}conductor/v1/instances/${SPARK_INSTANCE_GROUP_UUID}/sslconf/${TIER}" ${tlsVersion}`
        sslCertPath=`echo ${sslBody} | awk '{n=split($0,a,","); for (i=1; i<=n; i++) { print a[i] }}' | awk '{n=split($0,a,":\""); if ($0 ~ /tier3opensslcertpath/) print a[2]}' | tr "\"" " "`
        sslKeyPath=`echo ${sslBody} | awk '{n=split($0,a,","); for (i=1; i<=n; i++) { print a[i] }}' | awk '{n=split($0,a,":\""); if ($0 ~ /tier3opensslkeypath/) print a[2]}' | tr "\"" " "`
        sslPemPasswd=`echo ${sslBody} | awk '{n=split($0,a,","); for (i=1; i<=n; i++) { print a[i] }}' | awk '{n=split($0,a,":\""); if ($0 ~ /tier3opensslpempassword/) print a[2]}' | tr "\"" " "`
           
        if [ -n "${sslCertPath}" ] && [ -n "${sslKeyPath}" ] && [ -n "${sslPemPasswd}" ]; then
            #Expand the sslCertPath and sslKeyPath in case they have reference to any environment variables
            sslCertPath=`eval echo $sslCertPath`
            sslKeyPath=`eval echo $sslKeyPath`
            ascdConfBody=`curl $curlSecureOpt -s -b ${DATADIR}/${notebookcookieprefix}.$$ -H'Accept:application/json' -X GET "${CONDUCTOR_REST_URL}conductor/v1/ascdconf?key=ASC_VERSION" ${tlsVersion}`
            ascdVersion=`echo $ascdConfBody | awk '{n=split($0,a,":\""); if ($0 ~ /ASC_VERSION/) print a[2]}' | tr -d "\"" | tr -d "}"`
                
            if [ -n "${ascdVersion}" ]; then
                rm -rf ${DATADIR}/${notebookcookieprefix}.$$
            fi
        else 
            #REST API call must have failed - log the response body
            echo_log_to_file "$sslBody" $LOGFILE
        fi

        # exit after max retrial to retrieve SSL and ASCD_VERSION
        if [ -z "${sslCertPath}" ] || [ -z "${sslKeyPath}" ] || [ -z "${sslPemPasswd}" ] || [ -z "${ascdVersion}" ]; then
            echo_log_to_file "Notebook SSL information is not fetched successfully, please try to restart notebook service or check if the SSL is configured properly" $LOGFILE
            exit 6
        fi
        
        DECRYPT_UTILITY=${EGO_TOP}/conductorspark/${ascdVersion}/bin/aes-decrypt.sh
        TIER3_TMP_KEY_PATH=${DATADIR}/tier3Keyfile.key
        PEM_PHRASE=${DATADIR}/tmpfile
        
        #Create tmpfile
        if [ -f "${PEM_PHRASE}" ]; then
            rm -rf "${PEM_PHRASE}"
        fi
        
        touch "${PEM_PHRASE}"
        chmod 600 "${PEM_PHRASE}"
        
        #Decrypt AES PEM Passwd
        ${DECRYPT_UTILITY} ${sslPemPasswd} > ${PEM_PHRASE}
        if [ $? -ne 0 ]; then
            echo_log_to_file "An error has occurred when decrypting PEM Passphrase. Exit code $?" $LOGFILE
            exit 4
        fi
        
        #Strip PEM passphrase
        openssl rsa -in ${sslKeyPath} -out ${TIER3_TMP_KEY_PATH} -passin file:${PEM_PHRASE}
        if [ $? -ne 0 ]; then
            echo_log_to_file "An error occurred with OpenSSL. Exit code $?" $LOGFILE
            exit 5
        fi
        
        #Cleanup tmpfile
        if [ -f "${PEM_PHRASE}" ]; then
            rm -rf "${PEM_PHRASE}"
        fi
        
        # Get the ssl_option enumeration of the protocol constant
        for ((i=0; i<${#SSL_PROTOCOLS[*]}; i++));
        do
            if [ ${SSL_PROTOCOLS[i]} = "${SSL_PROTOCOL}" ]; then
                protocol_enumeration="$i"
                break
            fi
        done
        
        if [ -z "${protocol_enumeration}" ]; then
            echo_log_to_file "No such SSL protocol: ${SSL_PROTOCOL}" $LOGFILE
            exit 13
        fi

        #Update SSL info in notebook config file 
        sed -i "s,#\s*c.NotebookApp.certfile =.*$,c.NotebookApp.certfile = '${sslCertPath}',g" $CONFIG_FILE
        sed -i "s,c.NotebookApp.certfile =.*$,c.NotebookApp.certfile = '${sslCertPath}',g" $CONFIG_FILE
        sed -i "s,#\s*c.NotebookApp.keyfile =.*$,c.NotebookApp.keyfile = '${TIER3_TMP_KEY_PATH}',g" $CONFIG_FILE
        sed -i "s,c.NotebookApp.keyfile =.*$,c.NotebookApp.keyfile = '${TIER3_TMP_KEY_PATH}',g" $CONFIG_FILE
        sed -i "s,#\s*c.NotebookApp.ssl_options =.*$,c.NotebookApp.ssl_options = {'ssl_version': ${protocol_enumeration}},g" $CONFIG_FILE
        sed -i "s,c.NotebookApp.ssl_options =.*$,c.NotebookApp.ssl_options = {'ssl_version': ${protocol_enumeration}},g" $CONFIG_FILE
        
        #Set JEG SSL CACERT PATH
        JEG_CA_CERT_PATH=${ASCD_REST_CACERT_PATH}
    else
        rm -rf ${DATADIR}/${notebookcookieprefix}.$$
    fi
else
    masterurl=spark://$SPARKMS_HOST:$SPARK_MASTER_PORT
fi
echo_log_to_file "Master URL is $masterurl" $LOGFILE

#Parse out the data connector information
echo "${output}" |grep -qF "$activedataconnectors"
if [ $? -eq 0 ]; then
    activeDataconnectorsParam=`echo ${output} | awk '{n=split($0,a,":"); for (i=1; i<=n; i++) { if (a[i] ~ /activedataconnectors/) print a[i+1] }}'`
    #Parse out the contents between the [ ]
    activeDataconnectorsList=${activeDataconnectorsParam##[}
    activeDataconnectorsList=${activeDataconnectorsList%%]*}
    #Remove quotations from each data connector name in the array
    activeDataconnectorsList=`echo ${activeDataconnectorsList} | sed 's/\"//g'`
    echo_log_to_file "Active data connectors = $activeDataconnectorsList" $LOGFILE
fi

echo "${output}" |grep -qF "$defaultfsdataconnector"
if [ $? -eq 0 ]; then
    defaultFsDc=`echo ${output} | awk '{n=split($0,a,","); for (i=1; i<=n; i++) { if (a[i] ~ /defaultfsdataconnector/) print a[i] }}' | awk '{n=split($0,a,":\""); print a[2]}' | tr "\"}]" " "`
    defaultFsDc=`echo "$defaultFsDc" | tr -d '[:space:]'`
    echo_log_to_file "Data connector to use for fs.defaultFS = $defaultFsDc" $LOGFILE
fi

#Build up the PYSPARK_SUBMIT_ARGS and then export
pySparkSubmitArgs="--deploy-mode client --master $masterurl"
if [ -n "$EGO_SERVICE_CREDENTIAL" ] && [ "$EGO_SERVICE_CREDENTIAL" == "${EGO_SERVICE_CREDENTIAL// /}" ]; then
    egoCred=$EGO_SERVICE_CREDENTIAL
    egoCred=${egoCred//\"/\\\"}
    pySparkSubmitArgs="$pySparkSubmitArgs --conf spark.ego.credential=$egoCred"
fi
if [ -n "$activeDataconnectorsList" ]; then
    pySparkSubmitArgs="$pySparkSubmitArgs --conf spark.ego.dataconnectors=$activeDataconnectorsList"
fi

pySparkSubmitArgs="$pySparkSubmitArgs pyspark-shell"
export PYSPARK_SUBMIT_ARGS="$pySparkSubmitArgs"


#If default fs data connector is defined, we need to define CORE_SITE_DEFAULTFS_XML_FILENAME environment variables
#The hadoop configuration will be applied by the 01-defaultfs-setup.py script after SparkContext is initialized by 00-pyspark-setup.py
if [ -n "$defaultFsDc" ]; then
    coreSiteFilename="$defaultFsDc""_core-site_defaultfs.xml"
    if [ -n "$coreSiteFilename" ]; then
        #Set the filename in CORE_SITE_DEFAULTFS_XML_FILENAME
        export CORE_SITE_DEFAULTFS_XML_FILENAME=$coreSiteFilename
    else
        echo_log_to_file "Could not find the $coreSiteFilename file. No default data connector will be used." $LOGFILE
    fi
fi

start_jupyter_enterprisegatway() {
    if [ "${JEG_ENABLED}" != "TRUE" ]; then
        return
    fi
    
    $(is_version_equal_or_greater "${INSTALLED_VERSION}" "5.4.0")
    if [ $? -ne 0 ]; then
        return
    fi
    # Set JEG log level
    if [ -z "${JEG_LOG_LEVEL}" ]; then
        JEG_LOG_LEVEL="${DEFAULT_JEG_LOG_LEVEL}"
    fi

    # Overwrite with user defined values
    if [ -z "${JUPYTER_CULL_IDLE_TIMEOUT}" ]; then
        JUPYTER_CULL_IDLE_TIMEOUT=${DEFAULT_CULL_IDLE_TIMEOUT}
    fi

    if [ -z "${JUPYTER_CULL_INTERVAL}" ]; then
        JUPYTER_CULL_INTERVAL=${DEFAULT_CULL_INTERVAL}
    fi

    if [ -z "${JUPYTER_CULL_CONNECTED}" ]; then
        JUPYTER_CULL_CONNECTED=${DEFAULT_CULL_CONNECTED}
    fi

    if [ -z "${JUPYTER_CULL_BUSY}" ]; then
        JUPYTER_CULL_BUSY=${DEFAULT_CULL_BUSY}
    fi
    
    if [ -z "${JUPYTER_KERNEL_START_TIMEOUT}" ]; then
        JUPYTER_KERNEL_START_TIMEOUT=${DEFAULT_JEG_KERNEL_START_TIMEOUT}
    fi
    
    if [ -z "${JUPYTER_REQUEST_TIMEOUT}" ]; then
        JUPYTER_REQUEST_TIMEOUT=${DEFAULT_NB2KG_REQUEST_TIMEOUT}
    fi
    
    JEG_OPT="--MappingKernelManager.cull_idle_timeout=${JUPYTER_CULL_IDLE_TIMEOUT} \
             --MappingKernelManager.cull_interval=${JUPYTER_CULL_INTERVAL} \
             --MappingKernelManager.cull_connected=${JUPYTER_CULL_CONNECTED} \
             --MappingKernelManager.cull_busy=${JUPYTER_CULL_BUSY}"
    
    echo_log_to_file "Starting Jupyter Enterprisegateway." $LOGFILE
    orig_path=`pwd`
    cd $JUPYTER_CONFIG_DIR
    # SETUP JEG class loader for Jupyter
    sed -i "s,#\s*c.NotebookApp.session_manager_class =.*$,c.NotebookApp.session_manager_class = 'nb2kg.managers.SessionManager',g" $CONFIG_FILE
    sed -i "s,c.NotebookApp.session_manager_class =.*$,c.NotebookApp.session_manager_class = 'nb2kg.managers.SessionManager',g" $CONFIG_FILE
    sed -i "s,#\s*c.NotebookApp.kernel_manager_class =.*$,c.NotebookApp.kernel_manager_class = 'nb2kg.managers.RemoteKernelManager',g" $CONFIG_FILE
    sed -i "s,c.NotebookApp.kernel_manager_class =.*$,c.NotebookApp.kernel_manager_class = 'nb2kg.managers.RemoteKernelManager',g" $CONFIG_FILE
    sed -i "s,#\s*c.NotebookApp.kernel_spec_manager_class =.*$,c.NotebookApp.kernel_spec_manager_class = 'nb2kg.managers.RemoteKernelSpecManager',g" $CONFIG_FILE
    sed -i "s,c.NotebookApp.kernel_spec_manager_class =.*$,c.NotebookApp.kernel_spec_manager_class = 'nb2kg.managers.RemoteKernelSpecManager',g" $CONFIG_FILE

    # Setup JEG config file
    JEG_CONFIG_FILE=jupyter_enterprise_gateway_config.py
    sed -i "s,#\s*c.KernelGatewayApp.ip =.*$,c.KernelGatewayApp.ip = '$(hostname -f)',g" $JEG_CONFIG_FILE
    sed -i "s,c.KernelGatewayApp.ip =.*$,c.KernelGatewayApp.ip = '$(hostname -f)',g" $JEG_CONFIG_FILE
    sed -i "s,#\s*c.KernelGatewayApp.port_retries =.*$,c.KernelGatewayApp.port_retries = 1000,g" $JEG_CONFIG_FILE
    sed -i "s,c.KernelGatewayApp.port_retries =.*$,c.KernelGatewayApp.port_retries = 1000,g" $JEG_CONFIG_FILE
    sed -i "s,#\s*c.KernelGatewayApp.certfile =.*$,c.KernelGatewayApp.certfile = '${sslCertPath}',g" $JEG_CONFIG_FILE
    sed -i "s,c.KernelGatewayApp.certfile =.*$,c.KernelGatewayApp.certfile = '${sslCertPath}',g" $JEG_CONFIG_FILE
    sed -i "s,#\s*c.KernelGatewayApp.keyfile =.*$,c.KernelGatewayApp.keyfile = '${TIER3_TMP_KEY_PATH}',g" $JEG_CONFIG_FILE
    sed -i "s,c.KernelGatewayApp.keyfile =.*$,c.KernelGatewayApp.keyfile = '${TIER3_TMP_KEY_PATH}',g" $JEG_CONFIG_FILE
    sed -i "s,#\s*c.KernelGatewayApp.client_ca =.*$,c.KernelGatewayApp.client_ca = '${JEG_CA_CERT_PATH}',g" $JEG_CONFIG_FILE
    sed -i "s,c.KernelGatewayApp.client_ca =.*$,c.KernelGatewayApp.client_ca = '${JEG_CA_CERT_PATH}',g" $JEG_CONFIG_FILE
    sed -i "s,#\s*c.EnterpriseGatewayApp.conductor_endpoint =.*$,c.EnterpriseGatewayApp.conductor_endpoint = '${masterresturl}',g" $JEG_CONFIG_FILE
    sed -i "s,c.EnterpriseGatewayApp.conductor_endpoint =.*$,c.EnterpriseGatewayApp.conductor_endpoint = '${masterresturl}',g" $JEG_CONFIG_FILE
    sed -i "s,#\s*c.EnterpriseGatewayApp.unauthorized_users =.*$,c.EnterpriseGatewayApp.unauthorized_users = {''},g" $JEG_CONFIG_FILE
    sed -i "s,c.EnterpriseGatewayApp.unauthorized_users =.*$,c.EnterpriseGatewayApp.unauthorized_users = {''},g" $JEG_CONFIG_FILE
    
    # NB2KG SSL info
    export KG_CLIENT_KEY=${TIER3_TMP_KEY_PATH}
    export KG_CLIENT_CERT=${sslCertPath}
    export KG_CLIENT_CA=${JEG_CA_CERT_PATH}
    
    # NB2KG setting
    export KG_REQUEST_TIMEOUT=${JUPYTER_REQUEST_TIMEOUT}
    
    # Kernel level shared ENV
    export KERNEL_SPARK_HOME=${SPARK_HOME}
    export KERNEL_SIG_ID=${SPARK_INSTANCE_GROUP_UUID}
    export KERNEL_NOTEBOOK_DATA_DIR=${DATADIR}
    export KERNEL_NOTEBOOK_DEPLOY_DIR=${NOTEBOOK_DEPLOY_DIR}
    export KERNEL_NOTEBOOK_COOKIE_JAR=${notebookcookieegoprefix}.$$
    export KERNEL_CURL_SECURITY_OPT=${curlSecureOpt}
    export KERNEL_NOTEBOOK_MASTER_REST=${mastersubmissionurl}
    if [ "$decoupled" = "true" ]; then
        export KERNEL_PYSPARK_PYTHON=${conda_env_path}bin/python
    else
        export KERNEL_PYSPARK_PYTHON=$NOTEBOOK_DEPLOY_DIR/install/bin/python
    fi
    
    # Pass in user defined SPARK_OPTS from notebook env
    export KERNEL_SPARK_OPTS=${JUPYTER_SPARK_OPTS}
    
    # Server level setting
    export EGO_SERVICE_CREDENTIAL=${EGO_SERVICE_CREDENTIAL}
    export EG_KERNEL_LAUNCH_TIMEOUT=${JUPYTER_KERNEL_START_TIMEOUT}
    # IP BLACKLIST will make JEG filter-off all private/local IPs that cannot be used as response-address.
    export EG_LOCAL_IP_BLACKLIST=${JUPYTER_IP_BLACKLIST}
    
    JEG_LOG=$DATADIR/enterprise_gateway.log
    JEG_PIDFILE=$DATADIR/enterprise_gateway.pid
    # Backup existing JEG log 
    if [ -f $JEG_LOG ]; then
        mv $JEG_LOG $DATADIR/enterprise_gateway_`date +%Y%m%d_%H%M`.log
    fi
    
    ${conda_env_bin_path}jupyter enterprisegateway ${JEG_OPT} --log-level=${JEG_LOG_LEVEL} > $JEG_LOG 2>&1 &
    if [ "$?" -eq 0 ]; then
        echo $! > $JEG_PIDFILE
    else
        echo_log_to_file "Jupyter Enterprise Gateway failed to start. Exit Code $?." $LOGFILE
        exit 12
    fi
    
    # Check JEG process started
    JEG_STARTUP_COUNTER=0
    ps -p $(head -1 $JEG_PIDFILE) > /dev/null
    rc=$?
    while [ $rc -ne 0 ]; do
        sleep 1
        ps -p $(head -1 $JEG_PIDFILE) > /dev/null
        rc=$?
        if [[ "$JEG_STARTUP_COUNTER" -gt 5 ]]; then
            echo_log_to_file "Jupyter Enterprise Gateway process ID cannot be found." $LOGFILE
            exit 12
        fi
        JEG_STARTUP_COUNTER=$((JEG_STARTUP_COUNTER+1))
    done
    
    # Check JEG URL exist
    JEG_STARTUP_COUNTER=0
    while [ ! -s "$JEG_LOG" ]; do
        if [[ "$JEG_STARTUP_COUNTER" -gt 5 ]]; then
            echo_log_to_file "Jupyter Enterprise Gateway log file cannot be found." $LOGFILE
            exit 12
        fi
        sleep 1
        JEG_STARTUP_COUNTER=$((JEG_STARTUP_COUNTER+1))
    done
    
    export KG_URL=$(grep "Jupyter Enterprise Gateway at" $JEG_LOG | awk '{print $(NF)}')
    if [[ $KG_URL == http* ]]; then
        echo_log_to_file "Jupyter Enterprise Gateway started at $KG_URL." $LOGFILE
    else
        echo_log_to_file "Failed to retrieve Jupyter Enterprise Gateway URL." $LOGFILE
        exit 12
    fi
    
    cd $orig_path
}

cd $JUPYTER_NOTEBOOK_DIR

INSTALLED_VERSION=`${conda_env_bin_path}jupyter notebook --version`
if is_version_equal_or_greater "${INSTALLED_VERSION}" "5.0.0"; then
    ALLOW_ROOT="--allow-root"
fi

start_jupyter_enterprisegatway
${conda_env_bin_path}jupyter notebook ${ALLOW_ROOT} --notebook-dir=$JUPYTER_NOTEBOOK_DIR >> $LOGFILE 2>&1
if [ $? -eq 0 ] ;then
    # Keep the activity working
    while [ true ]; do sleep 10; done
else
    unsource_conda_environment
    exit
fi