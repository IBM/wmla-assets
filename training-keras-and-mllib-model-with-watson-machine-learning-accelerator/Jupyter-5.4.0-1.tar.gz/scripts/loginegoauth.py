"""Tornado handlers for logging into the notebook."""

#Copyright IBM Corporation 2015
#U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#IBM, the IBM logo and ibm.com are trademarks of International Business Machines Corp, registered in many jurisdictions worldwide. 
#Other product and service names might be trademarks of IBM or other companies. A current list of IBM trademarks is available on the web at "Copyright and trademark information" at www.ibm.com/legal/copytrade.shtml


import uuid
import os
import requests
import yaml

from tornado.escape import url_escape
from tornado.web import HTTPError
from tornado.log import access_log, app_log, gen_log

from ..auth.login import LoginHandler

class EgoLoginHandler(LoginHandler):
    """The IBM Platform Spectrum customized tornado login handler

    authenticates with an ASCD authentication REST API
    """

    def _render(self, message=None):
        self.write(self.render_template('loginegoauth.html',
                next=url_escape(self.get_argument('next', default=self.base_url)),
                message=message,
        ))

    def post(self):
        gen_log.debug("Inside post")
        typed_username = self.get_argument('username', default='')
        typed_password = self.get_argument('password', default='')
        cookie_options = self.settings.get('cookie_options', {})
        cookie_options.setdefault('httponly', True)
        if self.login_available(self.settings):
            if self.passwd_checkego(typed_username, typed_password):
                # tornado <4.2 has a bug that considers secure==True as soon as
                # 'secure' kwarg is passed to set_secure_cookie
                if self.settings.get('secure_cookie', self.request.protocol == 'https'):
                    cookie_options.setdefault('secure', True)
                self.set_secure_cookie(self.cookie_name, str(uuid.uuid4()), **cookie_options)
            else:
                self.set_status(401)
                self._render(message={'error': 'Invalid password'})
                return

        next_url = self.get_argument('next', default=self.base_url)
        if not next_url.startswith(self.base_url):
            # require that next_url be absolute path within our path
            next_url = self.base_url
        self.redirect(next_url)

    @classmethod
    def login_available(cls, settings):
        """Whether this LoginHandler is needed - and therefore whether the login page should be displayed."""
        return True

    @classmethod
    def get_conductor_rest_url(cls, targetPath):
        """Get Conductor REST URL endpoint"""
        conductorresturl = None
        try:
            conductorresturl = cls.get_env_variable('CONDUCTOR_REST_URL') + targetPath
        except KeyError:
            raise HTTPError(500, "The environment variable CONDUCTOR_REST_URL is not defined.")
        conductorrestcom = conductorresturl.split(':')
        if len(conductorrestcom) < 3 :
            raise HTTPError(500, "The value of CONDUCTOR_REST_URL is not in the right format.")
        return conductorresturl

    @classmethod
    def get_env_variable(cls, env_var):
        """Get specified environment variable"""
        try:
            return os.environ[env_var]
        except KeyError:
            raise HTTPError(500, "The environment variable " + env_var + " is not defined.")

    @classmethod
    def set_env_variable(cls, env_var, value):
        """Set specified environment variable"""
        try:
            os.environ[env_var] = value
        except Exception:
            gen_log.warn("Could not set " + env_var + " to " + value)
    
    @classmethod
    def get_cacert_path(cls, conductor_rest_url):
        """Get the ASCD_REST_CACERT_PATH if conductor_rest_url is https.
           Otherwise return False"""
        
        if conductor_rest_url.startswith("https://"):
            ascdCaCertPath = cls.get_env_variable("ASCD_REST_CACERT_PATH")
            gen_log.info("The cacert is " + ascdCaCertPath)
            return os.path.expandvars(ascdCaCertPath)
        else:
            return False
        
    @classmethod
    def update_conductor_rest_url(cls, cacertpath):
        ego_credential = cls.get_env_variable('EGO_SERVICE_CREDENTIAL')
        mgmtHostList = cls.get_env_variable('MANAGEMENT_HOST_LIST')
        conductorresturlwithouttarget = cls.get_conductor_rest_url('')
        conductorresturl = cls.get_conductor_rest_url('conductor/v1/auth/logon')

        # Call REST API to login using EGO service credential
        s = requests.Session()
        status_code = 999
        try:
            y = s.get(conductorresturl, headers={'Authorization': 'PlatformToken token='+ego_credential},verify=cacertpath)
            status_code = y.status_code
        except Exception as e:
            gen_log.warn("Failed to authenticate the user using REST API: " + conductorresturl)
            gen_log.warn(str(e))
            newConductorresturlArray = conductorresturl.split(":")
            mgmtHosts = mgmtHostList.split(",")
            if len(mgmtHosts) < 1 :
                gen_log.warn("mgmtHosts is empty.")
            for mgmtHost in mgmtHosts:
                newConductorresturl = newConductorresturlArray[0] + "://" + mgmtHost + ":" + newConductorresturlArray[2]
                gen_log.info("Trying Conductor REST URL: " + newConductorresturl)
                if newConductorresturl == conductorresturl:
                    continue
                try:
                    y = s.get(newConductorresturl, headers={'Authorization': 'PlatformToken token='+ego_credential},verify=cacertpath)
                    status_code = y.status_code
                    newConductorresturlArrayWithoutTarget = conductorresturlwithouttarget.split(":")
                    gen_log.debug("Setting new environment variable value: "+newConductorresturlArrayWithoutTarget[0] + "://" + mgmtHost + ":" + newConductorresturlArrayWithoutTarget[2])
                    cls.set_env_variable('CONDUCTOR_REST_URL', newConductorresturlArrayWithoutTarget[0] + "://" + mgmtHost + ":" + newConductorresturlArrayWithoutTarget[2])
                    conductorresturl = newConductorresturl
                    gen_log.debug("Testing new environment variable value: "+cls.get_conductor_rest_url('conductor/v1/auth/logon'))
                    
                    if status_code != requests.codes.ok:
                        gen_log.warn("Failed to authenticate the user using REST API: " + conductorresturl)
                    
                    break
                except Exception as e:
                    gen_log.warn("Failed to authenticate the user using REST API: " + conductorresturl)
                    gen_log.warn(str(e))

        if status_code != requests.codes.ok:
            raise HTTPError(status_code, "Failed to authenticate the user using REST API: " + conductorresturl)
    
    @classmethod
    def get_notebook_user_info(cls):
        """Get current notebook's owner and collaborators"""

        gen_log.debug("Inside get_notebook_user_info")

        sig_uuid = cls.get_env_variable('SPARK_INSTANCE_GROUP_UUID')
        ego_credential = cls.get_env_variable('EGO_SERVICE_CREDENTIAL')
        spark_ego_user = cls.get_env_variable('SPARK_EGO_USER')
        target_notebook_service = cls.get_env_variable('EGOSC_SERVICE_NAME')
        ego_top = cls.get_env_variable('EGO_TOP')

        conductorresturl = cls.get_conductor_rest_url('conductor/v1/auth/logon')
        notebookresturl = cls.get_conductor_rest_url('conductor/v1/instances/' + sig_uuid + "/notebooks")
        
        cacertpath = cls.get_cacert_path(conductorresturl)

        # Call REST API to login using EGO service credential
        s = requests.Session()
        status_code = requests.codes.ok
        try:
            y = s.get(conductorresturl, headers={'Authorization': 'PlatformToken token='+ego_credential},verify=cacertpath)
            status_code = y.status_code
        except Exception as e:
             gen_log.error(str(e))
             raise HTTPError(500, "Failed to authenticate the user using REST API: " + conductorresturl)

        if status_code != requests.codes.ok:
            raise HTTPError(status_code, "Failed to authenticate the user using REST API: " + conductorresturl)

        # Call REST API to get notebook's owner and collaborator list
        status_code = requests.codes.ok
        try:
            y = s.get(notebookresturl,verify=cacertpath)
            status_code = y.status_code
        except Exception as e:
             gen_log.error(str(e))
             raise HTTPError(500, "Failed to get the notebook owner and collaborators using REST API: " + notebookresturl)

        if status_code != requests.codes.ok:
            raise HTTPError(status_code, "Failed to get the notebook owner and collaborators using REST API: " + notebookresturl)

        username = ''
        collaborators = []

        notebooks = yaml.load(y.content)
        for notebook in notebooks:
            if 'servicename' in notebook and notebook['servicename'] == target_notebook_service:
                if 'username' in notebook:
                    username = notebook['username']
                if 'collaborators' in notebook:
                    collaborators = notebook['collaborators']

        gen_log.debug("Notebook " + target_notebook_service + ": user=" + username + ", collaborators=" + str(collaborators))

        if not username:
            username = spark_ego_user

        return (username, collaborators)
        

    @classmethod
    def passwd_checkego(cls, myusername, mypassword):
        """using ego rest api to do login authchecking."""

        gen_log.debug("Inside passwd_checkego. Authenticating: " + myusername)

        conductorresturl = cls.get_conductor_rest_url('conductor/v1/auth/logon')
        cacertpath = cls.get_cacert_path(conductorresturl)
        cls.update_conductor_rest_url(cacertpath)
        
        nb_username,nb_collaborators = cls.get_notebook_user_info()
        if not myusername or not mypassword:
            raise HTTPError(401, "The username and password cannot be empty.") 
        if myusername != nb_username and not myusername in nb_collaborators:
            raise HTTPError(401, "The specified user is neither a notebook owner nor a notebook collaborator.")

        #Get updated conductorresturl
        conductorresturl = cls.get_conductor_rest_url('conductor/v1/auth/logon')
        
        s = requests.Session()
        status_code = requests.codes.ok
        try:
            y = s.get(conductorresturl,auth=(myusername,mypassword),verify=cacertpath)
            status_code = y.status_code
        except Exception as e:
             gen_log.error(str(e))
             raise HTTPError(500, "Failed to authenticate the user using REST API: " + conductorresturl)

        if status_code != requests.codes.ok:
            raise HTTPError(status_code, "Failed to authenticate the user using REST API: " + conductorresturl)

        return True