#!/bin/bash

source ./scripts/common.inc
source ./scripts/jupyter.inc

declare -r notebookcookieegoprefix="cookie_notebook_ego"

#For non-docker, we want logging to go to the service_logs file
#For docker, we want to echo to stdout which is already redirected to the service_logs file and also picked up by the dockercontroller log
if [ -n "$DOCKER_SERVICE_LOGFILE" ]; then
	SERVICE_LOG_FILENAME=""
fi

echo_log_to_file "Stopping the Jupyter notebook service." $LOGFILE

setfacl -R -m m:rwx $NOTEBOOK_DATA_DIR/data
setfacl -R -m m:rwx $NOTEBOOK_DATA_DIR/notebooks
# Remove sticky bit
chmod -t -R $NOTEBOOK_DATA_DIR/data

if [ -n "$IPYTHONDIR" ]; then
    setfacl -R -m m:rwx $IPYTHONDIR
else
    setfacl -R -m m:rwx $NOTEBOOK_DATA_DIR/ipydir
fi

#Kill the Jupyter process and in the non-docker case, kill the process running start_jupyter.sh
IPID=`ps -ef|grep notebook |grep -F "$NOTEBOOK_DATA_DIR" |grep -v grep |awk '{print $2}'`
kill $IPID

# Check notebook server is shutdown
ps -p $IPID > /dev/null
rc=$?
while [ $rc -eq 0 ]; do
    sleep 2
    ps -p $IPID > /dev/null
    rc=$?
done

#Remove TMP SSL key
if [ -f "${DATADIR}/tier3Keyfile.key" ]; then
    rm -f "${DATADIR}/tier3Keyfile.key"
fi

#Remove notebook REST cookie jar
if ls ${DATADIR}/${notebookcookieegoprefix}.* > /dev/null 2>&1; then
    rm -f ${DATADIR}/${notebookcookieegoprefix}.*
fi

if [ -f "${DATADIR}/enterprise_gateway.pid" ]; then
    echo_log_to_file "Killing Jupyter Enterprise Gateway $(head -1 ${DATADIR}/enterprise_gateway.pid)." $LOGFILE
    kill -9 $(head -1 ${DATADIR}/enterprise_gateway.pid)
fi

if [ -n "$EGO_ACTIVITY_PID" ]; then
    kill $IPID $EGO_ACTIVITY_PID
fi