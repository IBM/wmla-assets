#!/usr/bin/env python

import redhareapiversion
from redhareapi import Kernel
import json

class MatchKernel(Kernel):
    def on_kernel_start(self, kernel_context):
        try:
            #Kernel.log_info("kernel id: " + kernel_context.get_id())
            Kernel.log_info("kernel input: " + kernel_context.get_model_description())
        except Exception as e:
            Kernel.log_error(str(e))

    def on_task_invoke(self, task_context):
        try:
            input_data = json.loads(task_context.get_input_data())
            a = input_data["a"]
            b = input_data["b"]
            task_context.set_output_data("{\"c\":" + str(a+b) + "}")
        except Exception as e:
            task_context.set_output_data(str(e))
            Kernel.log_error(str(e))

    def on_kernel_shutdown(self):
        print('on_kernel_shutdown')

if __name__ == '__main__':
    obj_kernel = MatchKernel()
    obj_kernel.run()