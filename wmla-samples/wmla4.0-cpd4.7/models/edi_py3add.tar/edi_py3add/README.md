# README of model py3add

## Summary

This is a simple example "a+b=c" which can be deployed into inference service.

## Input

* Input format: json
* Input body:

```
{
    "a" : 1,
    "b" : 2
}
```

## Output
* Output format: json
* Output body (if there is no error)
```
{
    "c" : 3
}
```

## Caller example

* call with curl without authentication, and ignore the SSL certification
```
curl -k -H "Content-type: application/json" -d '{"a":1,"b":2}' -X POST https://${YOUR_HOST}:9000/dlim/v1/inference/py3add
```